import { useSeriesEpisodesTmdb } from "backend/tmdb/useSeriesEpisodesTmdb";
import { useSearchParams } from "react-router-dom";
import { TMDBSeason } from "types/tmdb";

const ChoosePlayEpisodeMobile = ({
  seasons,
  setSelectedEpisode,
  setSelectedSeason,
  selectedSeason,
  tmdbId,
}: {
  seasons: TMDBSeason[];
  selectedSeason: number;
  setSelectedEpisode: React.Dispatch<React.SetStateAction<number>>;
  setSelectedSeason: React.Dispatch<React.SetStateAction<number>>;
  tmdbId?: string;
}) => {
  const [searchParams] = useSearchParams();
  const tmdb_id = tmdbId || searchParams.get("tmdb_id");
  const { data: dataEpisodes } = useSeriesEpisodesTmdb({
    config: {
      keepPreviousData: true,
    },
    params: {
      seasonNum: selectedSeason,
      tmdb_id: Number(tmdb_id),
    },
  });
  return (
    <div className="episode-choose">
      <select
        className="js-seasons tvshow-seasons"
        onChange={(e) => setSelectedSeason(Number(e.target.value))}
      >
        {seasons.map((season) => (
          <option value={season.season_number} key={season.id}>
            {season.name.replace("Season", "Temporada")}
          </option>
        ))}
      </select>
      <select
        className="js-episodes tvshow-episodes"
        onChange={(e) => setSelectedEpisode(Number(e.target.value))}
      >
        {dataEpisodes?.map((episode) => (
          <option key={`${episode.id}`} value={episode.episode_number}>
            {episode.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default ChoosePlayEpisodeMobile;
