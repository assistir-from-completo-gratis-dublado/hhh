import { useEpisodeDetailsTmdb } from "backend/tmdb/useEpisodeDetailsSeries";
import React from "react";
import { useSearchParams } from "react-router-dom";

const ChooseEpisodeDetails = ({
  tmdbId,
  selectedEpisode,
  selectedSeason,
  setBackgroundImageId,
}: {
  tmdbId?: string;
  selectedEpisode: number;
  selectedSeason: number;
  setBackgroundImageId: React.Dispatch<React.SetStateAction<string>>;
}) => {
  const [searchParams] = useSearchParams();
  const tmdb_id = tmdbId || searchParams.get("tmdb_id");
  const { isLoading, data } = useEpisodeDetailsTmdb({
    config: {
      keepPreviousData: true,
      staleTime: 10 * 60 * 1000,
      cacheTime: 15 * (60 * 1000),
      onSuccess(data) {
        if (!data) return;
        setBackgroundImageId(data.still_path);
      },
    },
    params: {
      episodeId: selectedEpisode,
      seasonId: selectedSeason,
      tmdb_id: Number(tmdb_id),
    },
  });
  if (isLoading || !data) return null;
  return (
    <>
      <div className="episode_name js-episode-name">{data.name}</div>
      <div className="episode_info">
        <b className="episode_number js-episode-number">Episódio {data.episode_number}</b>
      </div>
      <p className="episode_overview js-episode-overview">{data.overview}</p>
    </>
  );
};

export default ChooseEpisodeDetails;
