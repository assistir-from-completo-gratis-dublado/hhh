import { useSeriesEpisodesTmdb } from "backend/tmdb/useSeriesEpisodesTmdb";
import React from "react";
import { useSearchParams } from "react-router-dom";

const ChooseEpisodes = ({
  seasonNum,
  tmdbId,
  setSelectedEpisode,
}: {
  tmdbId?: string;
  seasonNum: number;
  setSelectedEpisode: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const [searchParams] = useSearchParams();
  const tmdb_id = tmdbId || searchParams.get("tmdb_id");
  const { data, isLoading } = useSeriesEpisodesTmdb({
    config: {
      keepPreviousData: true,
      staleTime: 10 * 60 * 1000,
      cacheTime: 15 * (60 * 1000),
    },
    params: {
      seasonNum,
      tmdb_id: Number(tmdb_id),
    },
  });
  if (isLoading || !data) return null;
  return (
    <div className="column episodes">
      <div className="scroller_cont">
        {data.map((episode) => (
          <div
            key={`${episode.id}`}
            className="row episode"
            onClick={() => setSelectedEpisode(episode.episode_number)}
          >
            <span className="episode_num">{episode.episode_number}</span> &nbsp; &nbsp;{" "}
            <span className="episode_title">{episode.name}</span>
            <div className="pseudo_click_listener" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default ChooseEpisodes;
