import { useState } from "react";
import { TMDBSeason } from "types/tmdb";
import classNames from "utils/classNames";
import ChooseEpisodes from "./ChooseEpisodes";
import ChooseEpisodeDetails from "./ChooseEpisodeDetails";
import ButtonAddFavorite from "../ButtonAddFavorite";
import { Link } from "react-router-dom";
import { PATH_APP } from "constants/path";
import { MediaType } from "types";

const SeriesEpisodes = ({
  tmdbId,
  poster,
  title,
  seasons,
  score,
  year,
  setBackgroundImageId,
  setIsOpen,
}: {
  seasons: TMDBSeason[];
  tmdbId: string;
  poster: string;
  year: number;
  score: number;
  title: string;
  setBackgroundImageId: React.Dispatch<React.SetStateAction<string>>;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
}) => {
  const [selectedSeason, setSelectedSeason] = useState(1);
  const [selectedEpisode, setSelectedEpisode] = useState(1);
  return (
    <div className="body">
      <div className="episode_choose_wrapper">
        <div className="column seasons">
          {seasons.map((season) => (
            <div className="scroller_cont" key={season.id}>
              <div
                className={classNames(
                  "row season",
                  season.season_number === selectedSeason ? "activated" : ""
                )}
                onClick={() => setSelectedSeason(season.season_number)}
              >
                {season.name.replace("Season", "Temporada")}
              </div>
            </div>
          ))}
        </div>
        <ChooseEpisodes
          tmdbId={tmdbId}
          seasonNum={selectedSeason}
          setSelectedEpisode={setSelectedEpisode}
        />
      </div>
      <div className="column content">
        <ChooseEpisodeDetails
          tmdbId={tmdbId}
          selectedEpisode={selectedEpisode}
          selectedSeason={selectedSeason}
          setBackgroundImageId={setBackgroundImageId}
        />
        <div id="watch_toolbox">
          <div className="toolbox_content">
            <div className="sep">
              <Link
                to={`${PATH_APP.watchTV}?tmdb_id=${tmdbId}&season=${selectedSeason}&episode=${selectedEpisode}`}
              >
                <div className="watch-btn player">
                  <div className="icon2 play" />
                  <div className="caption">ASSISTIR AGORA</div>
                </div>
              </Link>
            </div>
            <div className="sep" style={{ color: "rgba(255,255,255,0.7)" }}>
              <div className="tools">
                <ButtonAddFavorite
                  mediaType={MediaType.TV}
                  tmdbId={tmdbId}
                  poster={poster}
                  title={title}
                  score={score}
                  year={year}
                />
                <div className="tool trailer" onClick={() => setIsOpen(true)}>
                  Trailer
                </div>
                <br />
                <b className="tool data">Episódio {selectedEpisode}</b>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SeriesEpisodes;
