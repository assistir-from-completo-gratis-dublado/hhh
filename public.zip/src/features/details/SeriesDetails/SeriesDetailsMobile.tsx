import { useSeriesDetailsTmdb } from "backend/tmdb/useSeriesDetailsTmdb";
import { PATH_APP } from "constants/path";
import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link, useSearchParams } from "react-router-dom";
import DetailsRating from "../DetailsRating";
import ModalYoutubeTrailer from "../ModalYoutubeTrailer";
import ChoosePlayEpisodeMobile from "../SeriesEpisodes/ChoosePlayEpisodeMobile";
import ButtonAddFavorite from "../ButtonAddFavorite";
import { imageTMDB } from "backend/tmdb/image";
import { MediaType } from "types";

const SeriesDetailsMobile = ({ tmdbId }: { tmdbId?: string }) => {
  const [searchParams] = useSearchParams();
  const tmdb_id = tmdbId || searchParams.get("tmdb_id");
  const [isOpenTrailer, setOpenTrailer] = useState(false);
  const [selectedSeason, setSelectedSeason] = useState(1);
  const [selectedEpisode, setSelectedEpisode] = useState(1);
  const { data: details, isLoading: isLoadingTmdb } = useSeriesDetailsTmdb({
    params: {
      tmdb_id: tmdb_id || "",
    },
    config: {
      staleTime: 10 * 60 * 1000,
      cacheTime: 15 * (60 * 1000),
      enabled: Boolean(tmdb_id),
    },
  });
  if (isLoadingTmdb || !details) return null;
  return (
    <>
      <Helmet>
        <title>Assistir Série {details.name || details.original_name} Completa Grátis Legendado e Dublado Online HD</title>
        <meta property="og:description" content={details.overview} />
        <meta property="og:image" content={imageTMDB.image1280(details.backdrop_path)} />
      </Helmet>
      <div className="movie-menu">
        <Link to={PATH_APP.tv}>
          <div className="movie-menu__close-arrow" />
        </Link>
        <div className="logo-filmes2" style={{ top: "10px" }}><center><img src="https://i.ibb.co/BKVrq5D/logo.gif" alt="DONFLIX" width="134" height="86"/></center></div>
        <ButtonAddFavorite
          mediaType={MediaType.TV}
          tmdbId={details.id.toString()}
          poster={imageTMDB.image300(details.poster_path)}
          title={details.name || details.original_name}
          year={new Date(details.first_air_date).getFullYear()}
          score={details.vote_average}
        />
      </div>
      <div className="info-container js-backdrop">
        <div
          className="info-container__poster js-poster fadein"
          style={{
            backgroundImage: `-webkit-linear-gradient(top, rgba(0, 0, 0, 0) 0%, rgb(0, 0, 0) 100%), url(${imageTMDB.image1280(
              details.poster_path
            )})`,
          }}
        ></div>
        <div className="info-container__content movie-info">
          <DetailsRating score={details.vote_average / 2} />
          <div className="movie-info__title js-title">{details.name || details.original_name}</div>
          <div className="movie-info__details">
            <div className="movie-info__genres js-genres">{details.genres?.[0]?.name}</div>
            <div className="movie-info__year js-year">
              {new Date(details.first_air_date).getFullYear()}
            </div>
            {details.episode_run_time} min
          </div>
          <div className="controls">
            <Link
              to={`${PATH_APP.watchTV}?tmdb_id=${tmdb_id}&season=${selectedSeason}&episode=${selectedEpisode}`}
            >
              <div rel="modal" className="controls__play player">
                <svg
                  className="js-play play-button"
                  style={{ fill: "#888" }}
                  xmlns="http://www.w3.org/2000/svg"
                  width={24}
                  height={24}
                  viewBox="0 0 24 24"
                >
                  <path d="M6 6h12v12H6z" fill="#FFF" />
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" />
                </svg>
              </div>
            </Link>
          </div>
          <div className="synopsis-buttons">
            <div
              className="synopsis-buttons__trailer trailer-btn trailer"
              onClick={() => setOpenTrailer(true)}
            >
              TRAILER
            </div>
          </div>
          <div className="episode_info">
            <b className="js-episode-name" />
          </div>
          <div className="movie-synopsis js-episode-overview">{details.overview}</div>
          <ChoosePlayEpisodeMobile
            seasons={details.seasons}
            selectedSeason={selectedSeason}
            setSelectedEpisode={setSelectedEpisode}
            setSelectedSeason={setSelectedSeason}
          />
        </div>
      </div>
      <ModalYoutubeTrailer
        isOpen={isOpenTrailer}
        setIsOpen={setOpenTrailer}
        title={details?.name || details?.original_name}
        youtubeTrailerId={details.videos?.results?.[0]?.key}
      />
    </>
  );
};

export default SeriesDetailsMobile;
