import { useSeriesDetailsTmdb } from "backend/tmdb/useSeriesDetailsTmdb";
import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import DetailsRating from "../DetailsRating";
import ModalYoutubeTrailer from "../ModalYoutubeTrailer";
import SeriesEpisodes from "../SeriesEpisodes/SeriesEpisodes";
import { imageTMDB } from "backend/tmdb/image";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { PATH_APP } from "constants/path";

const SeriesDetailsDesktop = ({ tmdbId }: { tmdbId?: string }) => {
  const [searchParams] = useSearchParams();
  const tmdb_id = tmdbId || searchParams.get("tmdb_id");
  const [backgroundImageId, setBackgroundImageId] = useState("");
  const [isOpenTrailer, setOpenTrailer] = useState(false);
  const { data: details, isLoading: isLoadingTmdb } = useSeriesDetailsTmdb({
    params: {
      tmdb_id: tmdb_id || "",
    },
    config: {
      staleTime: 10 * 60 * 1000,
      cacheTime: 15 * (60 * 1000),
      enabled: Boolean(tmdb_id),
      onSuccess(data) {
        if (!data) return;
        setBackgroundImageId(data?.backdrop_path || data?.poster_path);
      },
    },
  });
  if (isLoadingTmdb || !details) return null;
  return (
    <>
      <Helmet>
        <title>Assistir Série {details.name || details.original_name} Completa Grátis Legendado e Dublado Online HD</title>
        <meta property="og:description" content={details.overview} />
        <meta
          property="og:image"
          content={`https://image.tmdb.org/t/p/w780${details.backdrop_path}`}
        />
      </Helmet>
      <Link to={PATH_APP.tv}>
        <button className="close" style={{ top: "10px" }}></button>
      </Link>
      <div className="backdrop">
        <div className="backdrop_img fadein">
          <div
            className="img fadein"
            style={{
              backgroundImage: `url("https://image.tmdb.org/t/p/w1280${
                backgroundImageId || details.backdrop_path
              }")`,
            }}
          />
        </div>
      </div>
      <div className="head">
        <div className="incont">
          <div
            className="poster fadein"
            style={{
              backgroundImage: `url("https://image.tmdb.org/t/p/w500${details.poster_path}")`,
            }}
          />
          <div className="info_cont">
            <div className="title js-title">{details.name || details.original_name}</div>
            <div className="title_info_cont">
              <div className="title_info genre js-genres">{details.genres?.[0]?.name}</div>
              <div className="title_info runtime_cont" style={{ display: "block" }}>
                <span className="icon2 time" /> {details.episode_run_time} min
                <span className="runtime js-runtime" />
              </div>
              <div className="title_info">
                <span className="icon2 date" /> &nbsp;
                <span className="year js-year">
                  {new Date(details.first_air_date).getFullYear()}
                </span>
              </div>
              <DetailsRating score={details.vote_average / 2} />
            </div>
            <div className="synopsis fadein">{details.overview}</div>
          </div>
        </div>
      </div>
      <SeriesEpisodes
        tmdbId={details.id.toString()}
        poster={imageTMDB.image300(details.poster_path)}
        title={details.name || details.original_name}
        year={new Date(details.first_air_date).getFullYear()}
        score={details.vote_average}
        setIsOpen={setOpenTrailer}
        seasons={details.seasons}
        setBackgroundImageId={setBackgroundImageId}
      />
      <ModalYoutubeTrailer
        isOpen={isOpenTrailer}
        setIsOpen={setOpenTrailer}
        title={details?.name || details?.original_name}
        youtubeTrailerId={details.videos?.results?.[0]?.key}
      />
    </>
  );
};

export default SeriesDetailsDesktop;
