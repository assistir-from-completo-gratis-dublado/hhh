import { imageTMDB } from "backend/tmdb/image";
import { useMovieDetailsTmdb } from "backend/tmdb/useMovieDetailsTmdb";
import { PATH_APP } from "constants/path";
import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link, useSearchParams } from "react-router-dom";
import ButtonAddFavorite from "../ButtonAddFavorite";
import DetailsRating from "../DetailsRating";
import ModalYoutubeTrailer from "../ModalYoutubeTrailer";
import { MediaType } from "types";

const MovieDetailsDesktop = ({ tmdbId }: { tmdbId?: string }) => {
  const [searchParams] = useSearchParams();
  const tmdb_id = tmdbId || searchParams.get("tmdb_id");
  const [isOpenTrailer, setOpenTrailer] = useState(false);
  const { data: details, isLoading: isLoadingTmdb } = useMovieDetailsTmdb({
    params: {
      tmdb_id: tmdb_id || "",
    },
    config: {
      staleTime: 10 * 60 * 1000,
      cacheTime: 15 * (60 * 1000),
      enabled: Boolean(tmdb_id),
    },
  });
  if (isLoadingTmdb || !details) return null;
  return (
    <>
      <Helmet>
        <title>Assistir Filme {details.title || details.original_title} Completo Grátis Legendado e Dublado Online HD</title>
        <meta property="og:description" content={details.overview} />
        <meta
          property="og:image"
          content={`https://image.tmdb.org/t/p/w780${details.backdrop_path}`}
        />
      </Helmet>
      <Link to={PATH_APP.home}>
      <div className="logo-filmes" style={{ top: "10px" }}><img src="https://i.ibb.co/BKVrq5D/logo.gif" alt="DONFLIX" width="134" height="86"/></div>
        <button className="close" style={{ top: "10px" }}></button>
      </Link>
      <div className="backdrop">
        <div className="backdrop_img fadein">
          <div
            className="img"
            style={{
              backgroundImage: `url(https://image.tmdb.org/t/p/w1280${details.backdrop_path})`,
            }}
          />
        </div>
      </div>
      <div className="movie_cont">
        <div className="incont">
          <img
            alt={details.title || details.title_english || details.title_portuguese}
            className="poster_img fadein"
            src={`https://image.tmdb.org/t/p/w780/${details.poster_path}`}
          />
          <div className="content">
            <div className="title js-title">
              {details.title || details.title_english || details.title_portuguese}
            </div>
            <div className="title_info_cont">
              <div className="title_info genre js-genres">{details.genres?.[0]?.name}</div>
              <div className="title_info">
                <span className="icon2 date" /> {new Date(details.release_date).getFullYear()}
              </div>
              <div className="title_info">
                <span className="icon2 time" />{" "}
                <span className="runtime js-runtime">{details.runtime} min</span>
                <DetailsRating score={details.vote_average / 2} />
              </div>
            </div>
            <div className="synopsis fadein">{details.overview}</div>
            <div className="actors" />
          </div>
        </div>
        <div id="watch_toolbox">
          <div className="toolbox_content">
            <div className="sep">
              <div className="watch-btn">
                <div className="icon2 play" />
                <Link to={`${PATH_APP.watchMovie}?tmdb_id=${tmdb_id}`}>
                  <div className="caption">ASSISTIR AGORA</div>
                </Link>
              </div>
            </div>
            <div className="sep" style={{ color: "rgba(255,255,255,0.7)" }}>
              <div className="tools">
                <ButtonAddFavorite
                  mediaType={MediaType.MOVIE}
                  tmdbId={details.id.toString()}
                  poster={imageTMDB.image300(details.poster_path)}
                  title={details.title || details.original_title}
                  year={new Date(details.release_date).getFullYear()}
                  score={details.vote_average}
                />
                {details.videos.results?.[0]?.key ? (
                  <div
                    className="tool trailer"
                    style={{ display: "block" }}
                    onClick={() => setOpenTrailer(true)}
                  >
                    Trailer
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      </div>
      <ModalYoutubeTrailer
        isOpen={isOpenTrailer}
        setIsOpen={setOpenTrailer}
        title={details?.title || details?.original_title}
        youtubeTrailerId={details.videos?.results?.[0]?.key}
      />
    </>
  );
};

export default MovieDetailsDesktop;
