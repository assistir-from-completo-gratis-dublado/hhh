import { imageTMDB } from "backend/tmdb/image";
import { useSeriesDetailsTmdb } from "backend/tmdb/useSeriesDetailsTmdb";
import { PATH_APP } from "constants/path";
import ButtonAddFavorite from "features/details/ButtonAddFavorite";
import DetailsRating from "features/details/DetailsRating";
import ModalYoutubeTrailer from "features/details/ModalYoutubeTrailer";
import ChoosePlayEpisodeMobile from "features/details/SeriesEpisodes/ChoosePlayEpisodeMobile";
import SeriesEpisodes from "features/details/SeriesEpisodes/SeriesEpisodes";
import React, { useState } from "react";
import { isMobile } from "react-device-detect";
import ReactModal from "react-modal";
import { Link } from "react-router-dom";
import { MediaType } from "types";
import { TMDBShowTVResult } from "types/tmdb";

const customStyles = {
  content: {
    border: "none",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    overflow: "hidden",
    zIndex: 100,
    background: "#000",
  },
};

const ModalSeriesDetails = ({
  movie,
  setModalInfo,
}: {
  movie: TMDBShowTVResult;
  setModalInfo: React.Dispatch<React.SetStateAction<TMDBShowTVResult | null>>;
}) => {
  const [selectedSeason, setSelectedSeason] = useState(1);
  const [selectedEpisode, setSelectedEpisode] = useState(1);
  const [isOpenTrailer, setOpenTrailer] = useState(false);
  const { data: details, isLoading: isLoadingTmdb } = useSeriesDetailsTmdb({
    params: {
      tmdb_id: movie.id.toString() || "",
    },
    config: {
      staleTime: 10 * 60 * 1000,
      cacheTime: 15 * (60 * 1000),
      enabled: Boolean(movie.id),
    },
  });
  if (isLoadingTmdb || !details) return null;
  return (
    <ReactModal
      isOpen={true}
      style={customStyles}
      onRequestClose={() => {
        setModalInfo(null);
      }}
      contentLabel={details.name}
    >
      <div id="slider_tvshow" className="slider fadein" style={{ top: 0, opacity: 1 }}>
        {isMobile ? (
          <>
            <div className="movie-menu">
              <button className="movie-menu__close-arrow" onClick={() => setModalInfo(null)} />
              <div className="logo-filmes2" style={{ top: "10px" }}><center><img src="https://i.ibb.co/BKVrq5D/logo.gif" alt="DONFLIX" width="134" height="86"/></center></div>
              <ButtonAddFavorite
                mediaType={MediaType.TV}
                tmdbId={details.id.toString()}
                poster={imageTMDB.image300(details.poster_path)}
                title={details.name || details.original_name}
                year={new Date(details.first_air_date).getFullYear()}
                score={details.vote_average}
              />
            </div>
            <div className="info-container js-backdrop">
              <div
                className="info-container__poster js-poster fadein"
                style={{
                  backgroundImage: `-webkit-linear-gradient(top, rgba(0, 0, 0, 0) 0%, rgb(0, 0, 0) 100%), url(${imageTMDB.image1280(
                    details.poster_path
                  )})`,
                }}
              ></div>
              <div className="info-container__content movie-info">
                <DetailsRating score={details.vote_average / 2} />
                <div className="movie-info__title js-title">
                  {details.name || details.original_name}
                </div>
                <div className="movie-info__details">
                  <div className="movie-info__genres js-genres">{details.genres?.[0]?.name}</div>
                  <div className="movie-info__year js-year">
                    {new Date(details.first_air_date).getFullYear()}
                  </div>
                  {details.episode_run_time} min
                </div>
                <div className="controls">
                  <Link
                    to={`${PATH_APP.watchTV}?tmdb_id=${movie.id}&season=${selectedSeason}&episode=${selectedEpisode}`}
                  >
                    <div rel="modal" className="controls__play player">
                      <svg
                        className="js-play play-button"
                        style={{ fill: "#888" }}
                        xmlns="http://www.w3.org/2000/svg"
                        width={24}
                        height={24}
                        viewBox="0 0 24 24"
                      >
                        <path d="M6 6h12v12H6z" fill="#FFF" />
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" />
                      </svg>
                    </div>
                  </Link>
                </div>
                <div className="synopsis-buttons">
                  <div
                    className="synopsis-buttons__trailer trailer-btn trailer"
                    onClick={() => setOpenTrailer(true)}
                  >
                    TRAILER
                  </div>
                </div>
                <div className="episode_info">
                  <b className="js-episode-name" />
                </div>
                <div className="movie-synopsis js-episode-overview">{details.overview}</div>
                <ChoosePlayEpisodeMobile
                  seasons={details.seasons}
                  selectedSeason={selectedSeason}
                  setSelectedEpisode={setSelectedEpisode}
                  setSelectedSeason={setSelectedSeason}
                  tmdbId={movie.id.toString()}
                />
              </div>
            </div>
          </>
        ) : (
          <>
           <div className="logo-filmes" style={{ top: "10px" }}><img src="https://i.ibb.co/BKVrq5D/logo.gif" alt="DONFLIX" width="134" height="86"/></div>
            <button className="close" onClick={() => setModalInfo(null)} />
            <div className="backdrop">
              <div className="backdrop_img fadein">
                <div
                  className="img fadein"
                  style={{
                    backgroundImage: `url("https://image.tmdb.org/t/p/w1280${details.backdrop_path}")`,
                  }}
                />
              </div>
            </div>
            <div className="head">
              <div className="incont">
                <div
                  className="poster fadein"
                  style={{
                    backgroundImage: `url("https://image.tmdb.org/t/p/w500${details.poster_path}")`,
                  }}
                />
                <div className="info_cont">
                  <div className="title js-title">{details.name || details.original_name}</div>
                  <div className="title_info_cont">
                    <div className="title_info genre js-genres">{details.genres?.[0]?.name}</div>
                    <div className="title_info runtime_cont" style={{ display: "block" }}>
                      <span className="icon2 time" /> {details.episode_run_time} min
                      <span className="runtime js-runtime" />
                    </div>
                    <div className="title_info">
                      <span className="icon2 date" /> &nbsp;
                      <span className="year js-year">
                        {new Date(details.first_air_date).getFullYear()}
                      </span>
                    </div>
                    <DetailsRating score={details.vote_average / 2} />
                  </div>
                  <div className="synopsis fadein">{details.overview}</div>
                </div>
              </div>
            </div>
            <SeriesEpisodes
              tmdbId={details.id.toString()}
              poster={imageTMDB.image300(details.poster_path)}
              title={details.name || details.original_name}
              year={new Date(details.first_air_date).getFullYear()}
              score={details.vote_average}
              setIsOpen={setOpenTrailer}
              seasons={details.seasons}
              setBackgroundImageId={() => {}}
            />
          </>
        )}
      </div>
      <ModalYoutubeTrailer
        isOpen={isOpenTrailer}
        setIsOpen={setOpenTrailer}
        title={details?.name || details?.original_name}
        youtubeTrailerId={details.videos?.results?.[0]?.key}
      />
    </ReactModal>
  );
};

export default ModalSeriesDetails;
