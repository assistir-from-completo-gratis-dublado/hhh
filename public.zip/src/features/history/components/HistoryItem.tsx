import LazyImage from "components/LazyImage";
import { PATH_APP } from "constants/path";
import { IHistoryItem } from "player/hooks/useSavedWatched";
import { Link } from "react-router-dom";
import { MediaType } from "types";
import { formatTimeDuration } from "utils/helper";

interface HistoryItemProps {
  movie: IHistoryItem;
  handleRemoveHistory: (movie: IHistoryItem) => void;
}

const HistoryItem = ({ movie, handleRemoveHistory }: HistoryItemProps) => {
  const episode = movie.mediaType !== MediaType.MOVIE ? ` - E${movie.currentEpisode}` : "";
  const href =
    movie.mediaType === MediaType.MOVIE
      ? `${PATH_APP.watchMovie}?tmdb_id=${movie.id}`
      : `${PATH_APP.watchTV}?tmdb_id=${movie.id}&episode=${movie.currentEpisode}&season=${movie.currentSeason}`;
  return (
    <div className="flex gap-3 lg:gap-5" key={movie.key}>
      <div className="flex-shrink-0 group overflow-hidden rounded lg:rounded-md max-w-[120px] relative bg-[#333] aspect-video w-full lg:max-w-[312px]">
        <Link to={href} className="max-w-[120px] w-full lg:max-w-[312px] aspect-video">
          <LazyImage
            alt={movie.name}
            src={movie.background}
            fallbackSrc={movie.poster}
            className="transition-all duration-200 group-hover:brightness-[0.4]"
          />
          {movie.mediaType === MediaType.TV && movie.currentEpisode ? (
            <div className="absolute z-10 flex items-center justify-center h-6 px-3 text-sm font-semibold text-white bg-[#0086d4] rounded top-2 right-2">
              {movie.currentSeason ? `T${movie.currentSeason} ` : null}E{movie.currentEpisode}
            </div>
          ) : null}
          <span className="absolute inline-block text-white lg:font-medium text-xs rounded lg:text-sm bottom-[6px] right-[2px] py-[2px] px-1 bg-black/80">
            {formatTimeDuration(movie.totalDuration)}
          </span>
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gray-600">
            <div
              className="history_currentTime"
              style={{ width: `${movie.progress.toFixed()}%` }}
            ></div>
          </div>
        </Link>
      </div>
      <div className="flex-1">
        <Link
          to={href}
          className="font-medium line-clamp-1 lg:line-clamp-2 lg:text-xl lg:font-semibold"
        >
          {movie.name}
          {episode}
        </Link>
        <p className="text-sm line-clamp-2 lg:text-base lg:line-clamp-3 lg:mt-2">
          {movie.description}
        </p>
      </div>
      <div className="flex flex-col items-center flex-shrink-0 gap-2">
        <button onClick={() => handleRemoveHistory(movie)}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth="1.5"
            stroke="currentColor"
            width="28"
            height="28"
            className="w-7 h-7"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        </button>
      </div>
    </div>
  );
};

export default HistoryItem;
