import MovieCard from "./MovieCard";

export default MovieCard;
