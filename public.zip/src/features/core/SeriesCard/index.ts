import SeriesCard from "./SeriesCard";

export default SeriesCard;
