import { imageTMDB } from "backend/tmdb/image";
import IconHalfStar from "components/Icons/IconHalfStar";
import IconStar from "components/Icons/IconStar";
import IconStarEmpty from "components/Icons/IconStarEmpty";
import LazyImage from "components/LazyImage";
import { PATH_APP } from "constants/path";
import ButtonAddFavorite from "features/details/ButtonAddFavorite";
import { NavLink } from "react-router-dom";
import { MediaType } from "types";
import { TMDBShowTVCard } from "types/tmdb";

const Rating = ({ value }: { value: number }) => {
  const stars = Array.from({ length: 5 }, () => <IconStarEmpty />);
  let i;
  for (i = 0; i < value; i++) {
    // this will loop Math.floor(value) times
    stars[i] = <IconStar />;
  }
  if (value % 1 !== 0)
    // if value is a decimal, add a half star
    stars[i - 1] = <IconHalfStar />;
  return (
    <div className="stars" style={{ fontSize: "34.68px" }}>
      {stars}
    </div>
  );
};

const SeriesCard = ({ movie }: { movie: TMDBShowTVCard }) => {
  return (
    <NavLink
      to={`${PATH_APP.detailsTv}?tmdb_id=${movie.id}`}
      style={{
        transitionDelay: "0s, 0.0434783s",
        opacity: 1,
        transform: "scale(1, 1)",
      }}
      className="movie p1"
    >
      <LazyImage src={`https://image.tmdb.org/t/p/w300${movie.poster_path}`} alt={movie.name} />
      <div className="poster_slide">
        <div className="poster_slide_cont">
          <div className="poster_slide_bg" />
          <div className="poster_slide_details">
            <div className="title">
              {movie.name || movie.original_name}
              <div className="year">
                <ButtonAddFavorite
                  mediaType={MediaType.TV}
                  tmdbId={movie.id.toString()}
                  poster={imageTMDB.image300(movie.poster_path)}
                  title={movie.name || movie.original_name}
                  year={new Date(movie.first_air_date).getFullYear()}
                  score={movie.vote_average}
                />{" "}
                &nbsp; {new Date(movie.first_air_date).getFullYear()}
              </div>
            </div>
            <div className="details">
              <div className="tools" style={{ display: "none", fontSize: "24.48px" }}>
                <ButtonAddFavorite
                  mediaType={MediaType.TV}
                  tmdbId={movie.id.toString()}
                  poster={imageTMDB.image300(movie.poster_path)}
                  title={movie.name || movie.original_name}
                  year={new Date(movie.first_air_date).getFullYear()}
                  score={movie.vote_average}
                />{" "}
                &nbsp;
                <span className="icon2 download" />
              </div>
              <Rating value={movie.vote_average / 2} />
            </div>
          </div>
        </div>
      </div>
    </NavLink>
  );
};

export default SeriesCard;
