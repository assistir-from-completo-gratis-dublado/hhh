export const TMDB_API_KEY = "95f2419536f533cdaa1dadf83c606027";
export const APP_DOMAIN = "https://donflix.pages.dev/";
export const APP_PROXIES = [
  "https://player.fekemif587.workers.dev",
  "https://player.donflixsupportsite.workers.dev",
  "https://hello-world-silent-pond-fe5d.feng5340.workers.dev",
];
export const APP_OPENSUBTITLES_API = "https://opensubtitles.soneme7359.workers.dev/?destination=";
