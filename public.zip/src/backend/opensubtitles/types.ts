import { ISubtitle } from "../../player";

export declare module OpenSubtitlesType {
  interface ISubtitleItem {
    languageName: string;
    subtitles: ISubtitle[];
  }
}
