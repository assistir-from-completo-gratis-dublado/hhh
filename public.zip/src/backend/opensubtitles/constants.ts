export const baseUrlDownloadOpensubtitles = "https://dl.opensubtitles.org";
