const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,HEAD,POST,OPTIONS",
  "Access-Control-Max-Age": "86400",
  "User-Agent": "TemporaryUserAgent",
};
async function handleRequest(oRequest, destination, iteration = 0) {
  const request = new Request(destination, oRequest);
  request.headers.set("Origin", new URL(destination).origin);
  request.headers.set("User-Agent", "TemporaryUserAgent");
  const oResponse = await fetch(request.clone());
  const response = new Response(oResponse.body, oResponse);
  response.headers.set("Access-Control-Allow-Origin", "*");
  response.headers.set("Access-Control-Expose-Headers", "*");
  const responseData = await response.json();
  if (responseData) {
    let modifiedData = JSON.stringify(
      responseData
        .reduce((acc, next) => {
          const index = acc.findIndex((item) => item.languageName === next.LanguageName);
          const newShortSubtitle = {
            language: next.LanguageName,
            url: next.ZipDownloadLink,
            lang: next.ISO639,
          };
          if (index === -1) {
            acc.push({
              languageName: next.LanguageName,
              subtitles: [newShortSubtitle],
            });
          } else {
            acc[index].subtitles.push(newShortSubtitle);
          }
          return acc;
        }, [])
        .sort((a) => {
          if (a.languageName.includes("Portuguese")) return -1;
          return 1;
        })
    );
    const modifiedResponse = new Response(modifiedData, response);
    return modifiedResponse;
  }
  return response;
}
function handleOptions(request) {
  const headers = request.headers;
  let response = new Response(null, {
    headers: {
      Allow: "GET, HEAD, POST, OPTIONS",
    },
  });
  if (
    headers.get("Origin") !== null &&
    headers.get("Access-Control-Request-Method") !== null &&
    headers.get("Access-Control-Request-Headers") !== null
  ) {
    response = new Response(null, {
      headers: {
        ...corsHeaders,
        "Access-Control-Allow-Headers": request.headers.get("Access-Control-Request-Headers"),
      },
    });
  }
  return response;
}
addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  const destination = url.searchParams.get("destination");
  let response = new Response("404 Not Found", {
    status: 404,
  });
  response = handleRequest(request, destination);
  event.respondWith(response);
});
