import { MediaType } from "types";
import { IMediaSource, IParamsMediaSource } from "../types";
import { ofetch } from "ofetch";
import { PATH_API } from "constants/path";
import { load } from "cheerio";
import { compareTitle, parseBetween } from "utils/helper";
import { getSourcesMovie, getSourcesSeries } from "../superstream";

const showboxBaseUrl = "https://www.showbox.media";
const febboxBaseUrl = "https://www.febbox.com";

type ISearchResult = {
  id: string;
  title: string;
  poster: string;
  mediaType: MediaType;
  year?: number;
  server?: string;
  seasons?: number;
};

const mappingId = {
  447365: {
    id: "movie/detail/49775",
    title: "Guardians of the Galaxy Vol. 3",
    url: "https://www.showbox.media/movie/detail/49775",
    poster:
      "https://thumb.showbox.media/thumb_dXBsb2FkaW1nL21vdmllLzIwMjIvMDcvMDcvMjAyMjA3MDcwODQ5MTExNTA2OC5qcGd8NTAwfDc0.png",
    mediaType: MediaType.MOVIE,
    server: "febbox",
  },
};

export const getMediaSourcesFebbox = async ({
  title,
  extraData,
}: IParamsMediaSource): Promise<IMediaSource> => {
  try {
    let foundResult: ISearchResult;
    if (extraData.tmdb_id && mappingId[extraData.tmdb_id as keyof typeof mappingId]) {
      foundResult = mappingId[extraData.tmdb_id as keyof typeof mappingId];
    } else {
      const searchHtml = await ofetch(
        PATH_API.BYPASS_CORS_WORKERS(
          `${showboxBaseUrl}/search?keyword=${encodeURIComponent(
            title.replace(/[^a-zA-Z0-9 ]/g, "").replace(/\s/g, "-")
          )}`
        )
      );
      const $ = load(searchHtml);
      let searchResults: ISearchResult[] = $(".film_list-wrap > div.flw-item")
        .toArray()
        .map((el) => {
          const releaseDate = $(el)
            .find("div.film-detail > div.fd-infor > span:nth-child(1)")
            .text();
          return {
            id: $(el).find("div.film-poster > a").attr("href")?.split("/").pop()!,
            title: $(el).find("div.film-detail > h2 > a").attr("title")!,
            year: isNaN(parseInt(releaseDate)) ? undefined : Number(releaseDate),
            seasons: releaseDate.includes("SS") ? parseInt(releaseDate.split("SS")[1]) : undefined,
            poster: $(el).find(".film-poster-img").attr("src") || "",
            mediaType:
              $(el).find("div.film-detail > div.fd-infor > span.float-right").text() === "Movie"
                ? MediaType.MOVIE
                : MediaType.TV,
          };
        });
      //remove results that dont match the media type
      searchResults = searchResults.filter((result) => {
        if (extraData.mediaType === MediaType.MOVIE)
          return (result.mediaType as string) === MediaType.MOVIE;
        else if (extraData.mediaType === MediaType.TV)
          return (result.mediaType as string) === MediaType.TV;
        else return result;
      });
      if (extraData.year && extraData.mediaType === MediaType.MOVIE) {
        searchResults = searchResults.filter((result) => {
          return Number(result.year) === extraData.year;
        });
      }
      if (extraData.totalSeasons && extraData.mediaType === MediaType.TV) {
        searchResults = searchResults.filter((result) => {
          if (!result.seasons) return false;
          const totalSeasons = (result.seasons as number) || 0;
          const extraDataSeasons = (totalSeasons as number) || 0;
          return (
            totalSeasons === extraDataSeasons ||
            totalSeasons === extraDataSeasons + 1 ||
            totalSeasons === extraDataSeasons - 1
          );
        });
      }
      searchResults = searchResults.filter((result) => compareTitle(result.title, title));
      foundResult = searchResults?.[0];
    }
    if (!foundResult) throw new Error(`Not found movie!`);
    const episodeId = Number(extraData.episodeId || 1);
    const episodes = await loadEpisodes(extraData, foundResult);
    const episodeIdProvider = episodes.find((ep) => ep.epNum === episodeId)?.id;
    if (!episodeIdProvider) throw new Error(`episodeIdProvider not found`);
    const [share_key, fid] = episodeIdProvider.split("_");
    const mediaSources = await getMediaSourcesFromFid(fid, share_key, foundResult.id, {
      title,
      extraData,
    });
    return mediaSources;
  } catch (error) {
    console.log("error: ", error);
    throw new Error("Unable to fetch movie stream");
  }
};

const getMediaSourcesFromFid = async (
  fid: string,
  share_key: string,
  foundResultId: string,
  { title, extraData }: IParamsMediaSource
): Promise<IMediaSource> => {
  const getMediaSourcesFebbox = async () => {
    const mediaSources: IMediaSource = {
      subtitles: [],
      sources: [],
    };
    const febboxPlayerHtml = await ofetch(
      PATH_API.BYPASS_CORS_WORKERS("https://www.febbox.com/file/player"),
      {
        method: "POST",
        body: `fid=${fid}&share_key=${share_key}`,
        headers: {
          "accept-language": "en", // without this header, the request is marked as a webscraper
          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
      }
    );
    const m3u8Id = parseBetween(febboxPlayerHtml, `file: '/hls/main/`, `.m3u8`);
    if (m3u8Id) {
      if (mediaSources.sources.length === 1) {
        mediaSources.sources.unshift({
          quality: "Auto",
          url: `https://www.febbox.com/hls/main/${m3u8Id}.m3u8`,
        });
      } else {
        mediaSources.sources.push({
          quality: "Auto",
          url: `https://www.febbox.com/hls/main/${m3u8Id}.m3u8`,
        });
      }
    }
    const sourcesJSON: ISourceJSON[] = JSON.parse(
      parseBetween(febboxPlayerHtml, `var sources = `, `];`) + `]`
    );
    if (sourcesJSON.length > 0) {
      sourcesJSON
        .filter((item) => item.label !== "ORG")
        .forEach((source) => {
          if (mediaSources.sources?.[0].quality === "360P") {
            mediaSources.sources.unshift({ url: source.file, quality: source.label });
          }
          mediaSources.sources.push({ url: source.file, quality: source.label });
        });
    }
    return mediaSources;
  };
  const [mediaSourcesFebbox, mediaSourcesSuperstream] = await Promise.all([
    getMediaSourcesFebbox(),
    extraData.mediaType === MediaType.MOVIE
      ? getSourcesMovie(Number(foundResultId))
      : getSourcesSeries(Number(foundResultId), extraData.episodeId || 1, extraData.seasonId || 1),
  ]);
  const mediaSources: IMediaSource = {
    subtitles: [...mediaSourcesSuperstream.subtitles, ...mediaSourcesFebbox.subtitles],
    sources: [...mediaSourcesSuperstream.sources, ...mediaSourcesFebbox.sources],
  };

  return mediaSources;
};

const loadEpisodes = async (query: IParamsMediaSourceExtraData, foundResult: ISearchResult) => {
  const febboxShareData = await ofetch(
    PATH_API.BYPASS_CORS_WORKERS(
      `${showboxBaseUrl}/index/share_link?id=${foundResult.id}&type=${
        query.mediaType === MediaType.MOVIE ? 1 : 2
      }`
    )
  );
  const febboxShareId = febboxShareData.data.link.split("/").pop();
  const dataList = await ofetch(
    `${febboxBaseUrl}/file/file_share_list?share_key=${febboxShareId}`,
    {
      parseResponse: JSON.parse,
    }
  );
  const file_list: IFile[] = dataList.data.file_list;
  if (file_list.length === 0) throw new Error(`Not found result`);
  if (query.mediaType === MediaType.MOVIE) {
    return [
      {
        id: `${febboxShareId}_${file_list[0].fid}`,
        epNum: 1,
      },
    ];
  }
  const parent_id = file_list.reverse()[Number(query.seasonId || 1) - 1].fid;
  const episodes: any[] = [];
  let page = 1;
  const getEpisodes = async (page = 1) => {
    const dataListChild = await ofetch(
      `${febboxBaseUrl}/file/file_share_list?share_key=${febboxShareId}&parent_id=${parent_id}&page=${page}`,
      {
        parseResponse: JSON.parse,
      }
    );
    const fileListChild: IFile[] = dataListChild.data.file_list;
    fileListChild
      .sort((a, b) => a.fid - b.fid)
      .forEach((item, index) => {
        const indexStartEp = item.file_name
          .toLowerCase()
          .indexOf(
            Number(query?.seasonId || 1) >= 10 ? `s${query.seasonId}e` : `s0${query.seasonId}e`
          );
        const epNum = parseInt(item.file_name.slice(indexStartEp + 4));
        if (epNum) {
          episodes.push({
            title: item.file_name,
            epNum: epNum ? epNum : index + 1,
            id: `${febboxShareId}_${item.fid}`,
          });
        }
      });
  };
  await getEpisodes();
  const firstEp = episodes.find((ep) => ep.epNum === 1);
  if (!firstEp && page < 3) {
    page = page + 1;
    await getEpisodes(page);
  }
  return episodes;
};

interface IFile {
  fid: number;
  uid: number;
  path: string;
  file_name: string;
  parent_id: number;
  share_id: number;
  thumb_small: string;
  thumb: string;
  quality: string;
  runtime: number;
}

interface ISourceJSON {
  file: string;
  type: string;
  label: string;
}
interface IParamsMediaSourceExtraData {
  episodeId?: number;
  seasonId?: number;
  mediaType: MediaType;
  year?: number;
  imdb_id?: string;
  tmdb_id?: number;
  totalSeasons?: number;
  totalEpisodes?: number;
  [key: string]: any;
}
