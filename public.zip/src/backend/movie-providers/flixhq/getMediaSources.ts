import extractUpCloud from "backend/extractors/upcloud";
import { load } from "cheerio";
import { MediaType } from "types";
import { compareTitle } from "utils/helper";
import { PATH_API } from "../../../constants/path";
import { IMediaSource, IParamsMediaSource } from "../types";
import { FlixhqType, ISearchResult } from "./types";
import { ofetch } from "ofetch";

export const FLIXHQ_BASE_URL = "https://flixhq.to";

export const getMediaSourcesFlixhq = async ({
  title,
  extraData,
}: IParamsMediaSource): Promise<IMediaSource> => {
  try {
    const mediaType = extraData.mediaType === MediaType.MOVIE ? "Movie" : "TV Series";
    const html = await ofetch(
      PATH_API.BYPASS_CORS_WORKERS(
        `${FLIXHQ_BASE_URL}/search/${encodeURIComponent(
          title.replace(/[^a-zA-Z0-9 ]/g, "").replace(/\s/g, "-")
        )}`
      )
    );
    const $ = load(html);
    let searchResults: ISearchResult[] = [];
    $("body .film_list-wrap > div.flw-item").each((_, el) => {
      const releaseDate = $(el).find("div.film-detail > div.fd-infor > span:nth-child(1)").text();
      searchResults.push({
        id: $(el).find("div.film-poster > a").attr("href")?.slice(1).split("/").pop()!,
        title: $(el).find(".film-name a").attr("title")!,
        url: `https://flixhq.to${$(el).find("div.film-poster > a").attr("href")}`,
        type:
          $(el).find("div.film-detail > div.fd-infor > span.float-right").text() === "Movie"
            ? FlixhqType.MOVIE
            : FlixhqType.TVSERIES,
        releaseDate: isNaN(parseInt(releaseDate)) ? undefined : releaseDate,
        seasons: releaseDate.includes("SS") ? parseInt(releaseDate.split("SS")[1]) : undefined,
      });
    });
    //remove results that dont match the media type
    searchResults = searchResults.filter((result: ISearchResult) => {
      if (mediaType === FlixhqType.MOVIE) return (result.type as string) === FlixhqType.MOVIE;
      else if (mediaType === FlixhqType.TVSERIES)
        return (result.type as string) === FlixhqType.TVSERIES;
      else return result;
    });
    // if extraData contains a year, filter out the results that don't match the year
    if (extraData.year && mediaType === FlixhqType.MOVIE) {
      searchResults = searchResults.filter((result: ISearchResult) => {
        return Number(result.releaseDate) === extraData.year;
      });
    }
    // check if the result contains the total number of seasons and compare it to the extraData by 1 up or down and make sure that its a number
    if (extraData.totalSeasons && mediaType === FlixhqType.TVSERIES) {
      searchResults = searchResults.filter((result: ISearchResult) => {
        if (!result.seasons) return false;
        const totalSeasons = (result.seasons as number) || 0;
        const extraDataSeasons = (totalSeasons as number) || 0;
        return (
          totalSeasons === extraDataSeasons ||
          totalSeasons === extraDataSeasons + 1 ||
          totalSeasons === extraDataSeasons - 1
        );
      });
    }
    searchResults = searchResults.filter((result: ISearchResult) =>
      compareTitle(result.title, title)
    );
    const foundResult = searchResults?.[0];
    let episodes: { id: string; ep: number }[] = [];
    const ajaxReqUrl = (id: string, type: string, isSeasons: boolean = false) =>
      PATH_API.BYPASS_CORS_WORKERS(
        `${FLIXHQ_BASE_URL}/ajax/${type === "movie" ? type : `v2/${type}`}/${
          isSeasons ? "seasons" : "episodes"
        }/${id}`
      );
    if (mediaType === FlixhqType.TVSERIES) {
      let seasonsIds: string[] = [];
      const dataTV = await ofetch(ajaxReqUrl(foundResult.url.split("-").pop()!, "tv", true));
      const $$ = load(dataTV);
      seasonsIds = $$(".dropdown-menu > a")
        .map((_, el) => $(el).attr("data-id"))
        .get();
      const foundSeasonId = seasonsIds[Number(extraData.seasonId || 1) - 1];
      const data = await ofetch(ajaxReqUrl(foundSeasonId, "season"));
      const $$$ = load(data);
      $$$(".nav > li")
        .each((_, el) => {
          const episode = {
            id: $$$(el).find("a").attr("id")!.split("-")[1],
            ep: parseInt($$$(el).find("a").attr("title")!.split(":")[0].slice(3).trim()),
          };
          episodes?.push(episode);
        })
        .get();
    }
    const ajaxUrlServers =
      mediaType === FlixhqType.MOVIE
        ? `${FLIXHQ_BASE_URL}/ajax/movie/episodes/${foundResult.url.split("-").pop()}`
        : `${FLIXHQ_BASE_URL}/ajax/v2/episode/servers/${
            episodes.find((ep) => ep.ep === Number(extraData.episodeId || 1))?.id
          }`;
    const dataServers = await ofetch(PATH_API.BYPASS_CORS_WORKERS(ajaxUrlServers));
    const $$$$ = load(dataServers);
    const upcloudServerId = $$$$(
      `.nav a[title='${mediaType === FlixhqType.MOVIE ? "UpCloud" : "Server UpCloud"}']`
    ).attr(mediaType === FlixhqType.MOVIE ? "data-linkid" : "data-id")!;
    if (!upcloudServerId) throw new Error(`Server upcloud not found`);
    const dataUpcloud = await ofetch(
      PATH_API.BYPASS_CORS_WORKERS(`${FLIXHQ_BASE_URL}/ajax/get_link/${upcloudServerId}`),
      { parseResponse: JSON.parse }
    );
    const mediaSources = await extractUpCloud(dataUpcloud.link);
    return mediaSources;
  } catch (error) {
    console.log("error: ", error);
    throw new Error("Unable to fetch movie stream");
  }
};
