export interface ISearchResult {
  id: number;
  box_type: number;
  title: string;
  actors: string;
  description: string;
  poster_min: string;
  poster_org: string;
  poster: string;
  banner_mini: string;
  cats: string;
  content_rating: number;
  runtime: number;
  year: number;
  collect: number;
  view: number;
  download: number;
  imdb_rating: string;
  is_collect: number;
  "3d": number;
  audio_lang: string;
  quality_tag: string;
  lang: string;
  trailer_url_arr: { url: string; img: string }[];
  trailer_url: string;
}

export interface ISources {
  path: string;
  quality: string;
  real_quality: string;
  format: string;
  size: string;
  size_bytes: number;
  count: number;
  dateline: number;
  fid: number;
  mmfid: number;
  h265: number;
  hdr: number;
  filename: string;
  original: number;
  colorbit: number;
  success: number;
  timeout: number;
  vip_link: number;
  fps: number;
  bitstream: string;
  width: number;
  height: number;
}

export interface ISubtitles {
  language: string;
  subtitles: ISubtitle[];
}

export interface ISubtitle {
  sid: number;
  mid: number;
  file_path: string;
  lang: string;
  language: string;
  delay: number;
  point: string | number;
  order: number;
  admin_order: number;
  myselect: number;
  add_time: number;
  count: number;
}
