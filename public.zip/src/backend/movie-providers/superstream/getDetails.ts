import { MediaType } from "types";
import { get } from "./utils";

export const getDetails = async (id: string, type: MediaType) => {
  const moduleType = type === MediaType.MOVIE ? "Movie_detail" : "TV_detail_1";
  const searchQuery = {
    module: moduleType,
    uid: "",
    oss: "",
    group: "",
    mid: id,
    tid: id,
  };
  return (await get(searchQuery, true).then((r) => r.json())).data;
};
