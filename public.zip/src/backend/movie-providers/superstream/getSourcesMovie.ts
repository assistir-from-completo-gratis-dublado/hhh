import { get, sortSourceSuperstream, sortSubtitlesSuperstream } from "./utils";

export const getSourcesMovie = async (moviedId: number) => {
  const apiQuery = {
    uid: "",
    module: "Movie_downloadurl_v3",
    mid: moviedId,
    oss: "1",
    group: ""
  };
  const subtitleApiQuery = {
    fid: "",
    uid: "",
    module: "Movie_srt_list_v2",
    mid: moviedId
  };
  try {
    const [mediaRes, subtitleRes] = await Promise.all([
      get(apiQuery).then((r) => r.json()),
      get(subtitleApiQuery).then((r) => r.json())
    ]);
    return {
      sources: sortSourceSuperstream(mediaRes.data.list),
      subtitles: sortSubtitlesSuperstream(subtitleRes.data.list)
    };
  } catch (error) {
    throw new Error("Unable to fetch movie stream");
  }
};
