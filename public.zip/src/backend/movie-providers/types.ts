import { MediaType } from "types";
import { ISource, ISubtitle } from "../../player/types";

export interface IServer {
  name: string;
  note: string;
  isSuccess?: boolean;
  get: (params: IParamsMediaSource) => Promise<IMediaSource> | IMediaSource;
}

export type IMediaServers = Array<IServer>;

export interface IParamsMediaSource {
  title: string;
  extraData: {
    episodeId?: number;
    seasonId?: number;
    mediaType: MediaType;
    year?: number;
    imdb_id?: string;
    tmdb_id?: number;
    totalSeasons?: number;
    totalEpisodes?: number;
    [key: string]: any;
  };
}

export interface IMediaSource {
  sources: ISource[];
  subtitles: ISubtitle[];
}
