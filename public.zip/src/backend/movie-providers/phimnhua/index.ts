import tmdbFetch from "backend/tmdb/tmdbFetch";
import { load } from "cheerio";
import { PATH_API } from "constants/path";
import { ofetch } from "ofetch";
import { MediaType } from "types";
import { compareTwoStrings, findM3u8FromString, findVTTFromString } from "utils/helper";
import { emptyMediaSources } from "../main-providers";
import { IMediaSource, IParamsMediaSource } from "../types";

const PHIM_NHUA_URL = "https://phimnhua.com";

export const getMediaSourcesPhimnhua = async ({
  title,
  extraData,
}: IParamsMediaSource): Promise<IMediaSource> => {
  const tmdbVietnameDetails = await tmdbFetch(
    `/${extraData.mediaType === MediaType.MOVIE ? "movie" : "tv"}/${extraData.tmdb_id}?language=vi`
  );
  const searchTitle =
    tmdbVietnameDetails?.title ||
    tmdbVietnameDetails?.original_title ||
    tmdbVietnameDetails?.name ||
    tmdbVietnameDetails?.original_name ||
    title;
  const html = await ofetch(
    PATH_API.BYPASS_CORS_WORKERS(`${PHIM_NHUA_URL}/?s=${encodeURIComponent(searchTitle)}`)
  );
  console.log("html: ", html);
  const $ = load(html);
  let searchResults: ISearchResult[] = $("body .card")
    .toArray()
    .map((movieEle) => {
      console.log("movieEle: ", movieEle);
      return {
        id: $(movieEle).find("h3 a").attr("href")?.split("/").reverse()[1]!,
        year: parseInt($(movieEle).find("h3 a")?.text().trim().slice(-5)!),
        mediaType: MediaType.TV,
        title: $(movieEle).find("h3 a")?.text()?.trim(),
        poster: $(movieEle).find("a img")?.attr("src")!,
        url: $(movieEle).find("h3 a").attr("href")!,
      };
    })
    .filter((result) => (extraData.year ? result.year === extraData.year : true))
    .sort((a, b) => {
      const firstRating = compareTwoStrings(extraData.title, a.title);
      const secondRating = compareTwoStrings(extraData.title, b.title);
      return secondRating - firstRating;
    });
  console.log("searchResults: ", searchResults);
  const foundResult = searchResults?.[0];
  console.log("foundResult: ", foundResult);
  const data = await ofetch(PATH_API.BYPASS_CORS_WORKERS(foundResult.url));
  console.log("data: ", data);
  if (extraData.mediaType === MediaType.MOVIE) {
    return {
      sources: [{ url: findM3u8FromString(data), quality: "Auto" }],
      subtitles: [{ url: findVTTFromString(data), lang: "vi", language: "Vietnamese" }],
    };
  }
  const $$ = load(data);
  const episodes = $$(".list.list-inline .list-inline-item")
    .toArray()
    .map((epEle, index) => {
      const [seasonStr, epStr] = $$(epEle).find("button").text().split("Tập");
      return {
        id: `${index + 1}`,
        epNum: parseInt(epStr),
        season: parseInt(seasonStr.replace("Phần", "")),
        title: $$(epEle).find("button").text(),
        thumbnail: $$('meta[property="og:image"]').attr("content") || "",
        mediaSources: {
          sources: [
            {
              quality: "Auto",
              url: $$(epEle).find("button").attr("data-url")!,
            },
          ],
          subtitles: [
            {
              lang: "vi",
              language: "Vietnamese",
              url: PATH_API.BYPASS_CORS_WORKERS(
                $$(epEle).find('input[name="caption"]').attr("value")!
              ),
            },
          ],
        },
      };
    });
  const foundEpisode = episodes.find(
    (ep) => ep.epNum === (extraData.episodeId || 1) && ep.season === (extraData.seasonId || 1)
  );
  return foundEpisode?.mediaSources || emptyMediaSources;
};

type ISearchResult = {
  id: string;
  title: string;
  poster: string;
  mediaType: MediaType;
  year?: number;
  server?: string;
  seasons?: number;
  url: string;
};
