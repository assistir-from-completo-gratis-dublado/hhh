export const remotestreamBase = `https://fsa.remotestre.am`;
