import { MediaType } from "types";
import { IMediaSource, IParamsMediaSource } from "../types";
import { remotestreamBase } from "./constants";

export const getMediaSourcesRemotestream = async ({
  extraData,
}: IParamsMediaSource): Promise<IMediaSource> => {
  try {
    const type = extraData.mediaType === MediaType.MOVIE ? "Movies" : "Shows";
    let playlistLink = `${remotestreamBase}/${type}/${extraData.tmdb_id}`;
    if (extraData.mediaType === MediaType.TV) {
      const seasonId = extraData.seasonId || "1";
      const episodeId = extraData.episodeId || "1";
      playlistLink += `/${seasonId}/${episodeId}/${episodeId}.m3u8`;
    } else {
      playlistLink += `/${extraData.tmdb_id}.m3u8`;
    }
    return { sources: [{ quality: "HD", url: playlistLink }], subtitles: [] };
  } catch (error) {
    console.log("error: ", error);
    throw new Error("Unable to fetch movie stream");
  }
};
