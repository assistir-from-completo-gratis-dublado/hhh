import { useQuery } from "@tanstack/react-query";
import { ExtractFnReturnType, QueryConfig } from "libs/react-query";
import { getMediaSourcesFlixhq } from "./flixhq";
import { IMediaSource, IParamsMediaSource, IServer } from "./types";
import { getMediaSourcesFebbox } from "./febbox";
import { getMediaSourcesSuperstream } from "./superstream";
import { getMediaSourcesPhimnhua } from "./phimnhua";

export const emptyMediaSources: IMediaSource = { sources: [], subtitles: [] };

export const allServers: IServer[] = [
  { name: "Opção 1", note: "", get: getMediaSourcesFebbox },
  { name: "Opção 2", note: "", get: getMediaSourcesFlixhq },
  { name: "Opção 3", note: "", get: getMediaSourcesSuperstream },
  { name: "Opção 4", note: "", get: getMediaSourcesPhimnhua },
  { name: "Embed", note: "Player contain ads", get: () => emptyMediaSources },
];

export const getMediaSources = async (params: IParamsMediaSource) => {
  let servers: IServer[] = allServers.map((x) => Object.assign({}, { ...x, isSuccess: true }));
  let mediaSources: IMediaSource = emptyMediaSources;
  for (let provider of servers) {
    try {
      const response = await provider.get(params);
      if (response?.sources?.length === 0) {
        provider.isSuccess = false;
        throw new Error(`Not found ${params.title} on ${provider.name}`);
      } else {
        mediaSources = response;
        provider.isSuccess = true;
        return { mediaSources, servers, activeServer: provider.name };
      }
    } catch (err) {
      console.log("err: ", err);
      provider.isSuccess = false;
      continue;
    }
  }
  return { mediaSources, servers, activeServer: servers[0].name };
};

type QueryFnType = typeof getMediaSources;

type UseMediaSourcesOptions = {
  params: IParamsMediaSource;
  config?: QueryConfig<QueryFnType>;
};

export const useMediaSources = ({ params, config }: UseMediaSourcesOptions) => {
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: ["mediaSources", params],
    queryFn: () => getMediaSources(params),
    staleTime: 25 * 60 * 1000,
    cacheTime: 30 * (60 * 1000),
  });
};
