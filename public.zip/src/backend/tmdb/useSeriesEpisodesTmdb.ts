import { useQuery } from "@tanstack/react-query";
import { ExtractFnReturnType, QueryConfig, queryClient } from "libs/react-query";
import tmdbFetch from "./tmdbFetch";
import { TMDBType } from "./types";

export const getSeriesEpisodesTmdb = async ({
  tmdb_id,
  seasonNum = 1,
}: {
  tmdb_id: number;
  seasonNum: number;
  language?: string;
}): Promise<TMDBType.IEpisode[]> => {
  try {
    if (!tmdb_id) return [];
    const { episodes }: { episodes: TMDBType.IEpisode[] } = await tmdbFetch(
      `/tv/${tmdb_id}/season/${seasonNum}`,
      { params: { language: "pt-BR" }, parseResponse: JSON.parse }
    );
    return episodes;
  } catch (error) {
    console.log("error: ", error);
    return [];
  }
};

type QueryFnType = typeof getSeriesEpisodesTmdb;

interface IParamsUseSeriesEpisodesTmdb {
  tmdb_id: number;
  seasonNum: number;
  language?: string;
}

type UseSeriesEpisodesTmdbOptions = {
  params: IParamsUseSeriesEpisodesTmdb;
  config?: QueryConfig<QueryFnType>;
};

const primaryKeyUseQuery = "SeriesEpisodesTmdb";

export const useSeriesEpisodesTmdb = ({ config = {}, params }: UseSeriesEpisodesTmdbOptions) => {
  const language = params.language || "en";
  return useQuery<ExtractFnReturnType<QueryFnType>>({
    ...config,
    queryKey: [primaryKeyUseQuery, params.tmdb_id, params.seasonNum, language],
    queryFn: () =>
      getSeriesEpisodesTmdb({
        tmdb_id: params.tmdb_id,
        seasonNum: params.seasonNum,
        language: "pt-BR",
      }),
  });
};

export const getQueryDataSeriesEpisodesTmdb = (params: IParamsUseSeriesEpisodesTmdb) => {
  const language = params.language || "en";
  return queryClient.getQueryData([
    primaryKeyUseQuery,
    params.tmdb_id,
    params.seasonNum,
    language,
  ]) as TMDBType.IEpisode[];
};
