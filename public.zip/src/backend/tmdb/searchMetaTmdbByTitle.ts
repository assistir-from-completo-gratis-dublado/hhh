import { compareTwoStrings } from "utils/helper";
import tmdbFetch from "./tmdbFetch";
import { IParamsSearchTMDB, ISearchResult } from "./types";

interface IResSearchResults {
  results: ISearchResult[];
  total_pages: number;
}

export const searchMetaTmdbByTitle = async ({ title, extraData }: IParamsSearchTMDB) => {
  try {
    const cleanName = title.replace(/\B(?=[A-Z])|\s*\d{4}\b/g, "");
    let { results: searchResults }: IResSearchResults = await tmdbFetch(`/search/multi`, {
      params: {
        query: cleanName,
      },
      parseResponse: JSON.parse,
    });
    searchResults = searchResults.sort((result: ISearchResult) =>
      compareTwoStrings((result.title || result.name) as string, cleanName)
    );
    if (extraData && extraData.year) {
      searchResults = searchResults.filter((result: ISearchResult) => {
        return (
          new Date(result?.release_date || (result.first_air_date as any)).getFullYear() ===
          extraData.year
        );
      });
    }
    const foundResult: ISearchResult = searchResults?.[0];
    if (!foundResult) return null;
    return foundResult;
  } catch (error) {
    console.log("error: ", error);
    return null;
  }
};
