export const imageTMDB = {
  imageOriginal: (url: string) => `https://image.tmdb.org/t/p/original${url}`,
  imageSize: (url: string, size: string) => `https://image.tmdb.org/t/p/${size}${url}`,
  image500: (url: string) => `https://image.tmdb.org/t/p/w500${url}`,
  image1280: (url: string) => `https://image.tmdb.org/t/p/w1280${url}`,
  image300: (url: string) => `https://image.tmdb.org/t/p/w300${url}`,
  image185: (url: string) => `https://image.tmdb.org/t/p/w185${url}`,
};
