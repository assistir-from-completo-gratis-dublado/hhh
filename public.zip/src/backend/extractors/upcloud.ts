import { IMediaSource } from "backend/movie-providers/types";
import { PATH_API } from "constants/path";
import { AES, enc } from "crypto-js";
import { ofetch } from "ofetch";

const decodeSources = (key: [number, number][], streamUrl: string) => {
  const decodedSource: string[] = streamUrl.split("");
  let newDecryptKey = "";
  for (const index of key) {
    for (let i = index[0]; i < index[1]; i++) {
      newDecryptKey += decodedSource[i];
      decodedSource[i] = "";
    }
  }
  streamUrl = decodedSource.join("");
  const decryptedVal = AES.decrypt(streamUrl, newDecryptKey).toString(enc.Utf8);
  return JSON.parse(decryptedVal);
};

const extractUpCloud = async (videoUrl: string): Promise<IMediaSource> => {
  const id = videoUrl.split("/").pop()?.split("?")[0];
  const [ajaxSources, e4Key] = await Promise.all([
    ofetch(
      PATH_API.BYPASS_CORS_WORKERS(`https://rabbitstream.net/ajax/embed-4/getSources?id=${id}`),
      {
        headers: { "X-Requested-With": "XMLHttpRequest" },
        parseResponse: JSON.parse,
      }
    ),
    ofetch(PATH_API.BYPASS_CORS_WORKERS("https://e4.tvembed.cc/e4"), { parseResponse: JSON.parse }),
  ]);
  let encodedSources: { file: string; type: string }[] = [];
  try {
    encodedSources = decodeSources(e4Key, ajaxSources.sources);
  } catch (error: any) {
    console.log("error: ", error);
    if (error.message === "Malformed UTF-8 data") {
      const fallbackKey = await ofetch(
        PATH_API.BYPASS_CORS_WORKERS(
          "https://raw.githubusercontent.com/Claudemirovsky/keys/e4/key"
        ),
        { parseResponse: JSON.parse }
      );
      encodedSources = decodeSources(fallbackKey, ajaxSources.sources);
    }
  }
  const m3u8Raw = await ofetch<string>(encodedSources[0].file, { parseResponse: (txt) => txt });
  const lines = m3u8Raw.split("\n");
  const urls = lines.filter((line) => line.includes(".m3u8"));
  const m3u8sources = lines.filter((line) => line.includes("RESOLUTION="));
  const sources = m3u8sources.map((s, i) => {
    const f1 = s.split("x")[1];
    const f2 = urls[i];
    return { quality: f1, url: f2 };
  });
  return {
    sources,
    subtitles: ajaxSources.tracks.map((s: any) => ({
      url: s.file,
      lang: s.label ? s.label : "Default (maybe)",
      language: s.label ? s.label : "Default (maybe)",
    })),
  };
};

export default extractUpCloud;
