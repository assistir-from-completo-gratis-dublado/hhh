import React, { ButtonHTMLAttributes, memo } from "react";
import { defaultI18n } from "../../constants/i18n";
import { useGlobalStateContext } from "../../contexts/GlobalStateContext";
import { useI18nContext } from "../../contexts/I18nContext";
import { download } from "../../utils/helper";
import IconCamera from "../../components/Icons/IconCamera";
import slugify from "slugify";
import { randomString } from "../../../utils/helper";

interface ButtonScreenshotMemoProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  playerRef: React.RefObject<HTMLVideoElement> | undefined;
}

const ButtonScreenshotMemo = memo((props: ButtonScreenshotMemoProps) => {
  const { playerRef, title, ...others } = props;
  const { i18n } = useI18nContext();
  const handleScreenShot = () => {
    if (!playerRef || !playerRef.current) return;
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    canvas.width = playerRef.current.videoWidth;
    canvas.height = playerRef.current.videoHeight;
    ctx.drawImage(playerRef.current, 0, 0);
    const fileName =
      (title
        ? slugify(title, {
            lower: true,
            remove: /[*+~.()'"!:@]/g,
          })
        : randomString(10)) + ".png";
    const imageUrl = canvas.toDataURL("image/png");
    download(imageUrl, fileName);
  };
  return (
    <button
      onClick={handleScreenShot}
      className="embed-tooltips-right embed-scale"
      data-embed-tooltips={i18n?.tooltipsScreenshot || defaultI18n.tooltipsScreenshot}
      {...others}
    >
      <IconCamera className="embed-icon-lg" />
    </button>
  );
});

ButtonScreenshotMemo.displayName = "ButtonScreenshotMemo";

const ButtonScreenshot = () => {
  const { meta, playerRef, heading } = useGlobalStateContext();
  return <ButtonScreenshotMemo playerRef={playerRef} title={meta?.title || heading} />;
};

export default ButtonScreenshot;
