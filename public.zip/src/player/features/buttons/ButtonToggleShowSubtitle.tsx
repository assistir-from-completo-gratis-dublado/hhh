import { ButtonHTMLAttributes, Dispatch, memo, useEffect, useRef } from "react";
import IconToggleSubtitle from "../../components/Icons/IconToggleSubtitle";
import { emptySubtitle } from "../../constants";
import { defaultI18n } from "../../constants/i18n";
import { useGlobalStateContext } from "../../contexts/GlobalStateContext";
import { useI18nContext } from "../../contexts/I18nContext";
import { ISubtitleState, useSubtitleStateContext } from "../../contexts/SubtitleStateContext";
import { IKeyBoardShortcut, ISubtitle } from "../../types";

interface ButtonToggleShowSubtitleMemoProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  subtitles: ISubtitle[] | undefined;
  isHasSubtitle: boolean;
  setMediaState: Dispatch<React.SetStateAction<ISubtitleState>>;
  keyboardShortcut: boolean | IKeyBoardShortcut | undefined;
}

const ButtonToggleShowSubtitleMemo = memo((props: ButtonToggleShowSubtitleMemoProps) => {
  const subtitleButtonRef = useRef<HTMLButtonElement>(null);
  const { subtitles, keyboardShortcut, isHasSubtitle, setMediaState, ...others } = props;
  const { i18n } = useI18nContext();
  const handleToggleShowSubtitle = () => {
    isHasSubtitle
      ? setMediaState((prevState) => ({
          ...prevState,
          subtitleSelected: emptySubtitle,
        }))
      : setMediaState((prevState) => ({
          ...prevState,
          subtitleSelected: subtitles?.[0] || emptySubtitle,
        }));
  };
  useEffect(() => {
    const keyHandler = (e: KeyboardEvent) => {
      if (!keyboardShortcut) return;
      if ((keyboardShortcut === true || keyboardShortcut.subtitle) && e.key === "c") {
        subtitleButtonRef.current?.click();
      }
    };
    window.addEventListener("keyup", keyHandler);
    return () => {
      window.removeEventListener("keyup", keyHandler);
    };
  }, [keyboardShortcut]);
  if (!Boolean(subtitles)) return null;
  return (
    <button
      ref={subtitleButtonRef}
      data-embed-tooltips={i18n?.tooltipsSubtitles || defaultI18n.tooltipsSubtitles}
      onClickCapture={handleToggleShowSubtitle}
      {...others}
    >
      <IconToggleSubtitle className="p-1 embed-icon-lg" />
    </button>
  );
});

ButtonToggleShowSubtitleMemo.displayName = "ButtonToggleShowSubtitleMemo";

const ButtonToggleShowSubtitle = () => {
  const { mediaState, setMediaState } = useSubtitleStateContext();
  const { subtitles, keyboardShortcut } = useGlobalStateContext();
  const isHasSubtitle = mediaState.subtitleSelected.url;
  return (
    <ButtonToggleShowSubtitleMemo
      isHasSubtitle
      subtitles={subtitles}
      setMediaState={setMediaState}
      className={`embed-center-container embed-scale ${
        isHasSubtitle ? "embed-icon-underline" : ""
      }`}
      keyboardShortcut={keyboardShortcut}
    />
  );
};

export default ButtonToggleShowSubtitle;
