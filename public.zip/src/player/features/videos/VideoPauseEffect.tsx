import React, { FC, memo } from "react";
import PauseIcon from "../../components/Icons/IconPause";

const PauseEffect: FC = () => {
  return (
    <div className="embed-fade-zoom-out embed-effect-icon">
      <PauseIcon className="embed-icon-lg" />
    </div>
  );
};

export default memo(PauseEffect);
