import React, { RefObject, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createContext, useContextSelector } from "use-context-selector";

interface LiveStreamSettingsProviderProps {
  children: React.ReactNode;
}

export enum LiveStreamSettingSections {
  main = "main",
  qualities = "qualities"
}

export interface ILiveStreamSettingsContext {
  sections: { [key in LiveStreamSettingSections]: RefObject<HTMLDivElement> | null };
  activeSection: LiveStreamSettingSections;
  setActiveSection: React.Dispatch<React.SetStateAction<LiveStreamSettingSections>>;
  height: number;
  updateHeightLiveStreamSettingsDialog: (height?: number) => void;
}

const LiveStreamSettingsContext = createContext<ILiveStreamSettingsContext>({
  sections: {
    [LiveStreamSettingSections.main]: null,
    [LiveStreamSettingSections.qualities]: null
  },
  activeSection: LiveStreamSettingSections.main,
  setActiveSection: () => {},
  height: 80,
  updateHeightLiveStreamSettingsDialog: () => {}
});

function LiveStreamSettingsProvider(props: LiveStreamSettingsProviderProps) {
  const [height, setHeight] = useState(80);
  const [activeSection, setActiveSection] = useState(LiveStreamSettingSections.main);
  const mainRef = useRef<HTMLDivElement>(null);
  const qualitisRef = useRef<HTMLDivElement>(null);
  const sections = useMemo<{ [key in LiveStreamSettingSections]: RefObject<HTMLDivElement> }>(
    () => ({
      [LiveStreamSettingSections.main]: mainRef,
      [LiveStreamSettingSections.qualities]: qualitisRef
    }),
    []
  );
  const updateHeightLiveStreamSettingsDialog = useCallback(
    (height?: number) => {
      if (sections[activeSection]?.current) {
        if (height) {
          setHeight(height);
        } else {
          const elementHeight = Number(sections[activeSection].current?.offsetHeight);
          setHeight(elementHeight > 400 ? 400 : elementHeight);
        }
        sections[activeSection].current?.scrollTo &&
          sections[activeSection].current?.scrollTo(0, 0);
      }
    },
    [activeSection, sections]
  );
  useEffect(() => {
    updateHeightLiveStreamSettingsDialog();
  }, [updateHeightLiveStreamSettingsDialog]);
  const contextValue = useMemo(
    () => ({
      sections,
      activeSection,
      setActiveSection,
      height,
      updateHeightLiveStreamSettingsDialog
    }),
    [sections, activeSection, setActiveSection, updateHeightLiveStreamSettingsDialog, height]
  );
  return (
    <LiveStreamSettingsContext.Provider value={contextValue}>
      {props.children}
    </LiveStreamSettingsContext.Provider>
  );
}

function useLiveStreamSettingsContext() {
  const context = useContextSelector(LiveStreamSettingsContext, (state) => state);
  if (typeof context === "undefined") {
    throw new Error(
      "useLiveStreamSettingsContext must be used within a LiveStreamSettingsProvider"
    );
  }
  return context;
}

export { LiveStreamSettingsProvider, useLiveStreamSettingsContext };
