import classNames from "../../../utils/classNames";
import { memo } from "react";
import { isMobile } from "react-device-detect";
import { useGlobalStateContext } from "../../contexts/GlobalStateContext";
import { useHoverStateContext } from "../../contexts/HoverStateContext";
import ButtonFullscreen from "../buttons/ButtonFullscreen";
import ButtonPlay from "../buttons/ButtonPlay";
import ButtonVolume from "../buttons/ButtonVolume";
import VideoVolumeSlider from "../videos/VideoVolumeSlider";

interface LiveStreamControlsMemoProps {
  isHoverEnabled: boolean;
  heading: string;
  handleClearTimeout: () => void;
  updateHoverState: () => void;
}

const LiveStreamControlsMemo = memo(
  ({
    heading,
    handleClearTimeout,
    isHoverEnabled,
    updateHoverState,
  }: LiveStreamControlsMemoProps) => {
    return (
      <div
        onTouchEnd={updateHoverState}
        onClick={updateHoverState}
        onMouseEnter={handleClearTimeout}
        className={classNames("embed-controls", isHoverEnabled && "embed-show")}
      >
        <div className="embed-controls-main">
          <div className="embed-controls-section">
            {!isMobile ? <ButtonPlay /> : null}
            <div className="embed-volume-container">
              <ButtonVolume />
              <VideoVolumeSlider />
            </div>
            <div className="flex items-center gap-x-2 md:gap-x-4">
              <div className="w-[10px] h-[10px] bg-red-600 rounded-full md:w-4 md:h-4"></div>
              <span>Live</span>
            </div>
          </div>
          {isMobile ? null : (
            <div className="absolute text-xl font-semibold -translate-x-1/2 -translate-y-1/2 line-clamp-1 top-1/2 left-1/2 drop-shadow-md shadow-black">
              {heading}
            </div>
          )}
          <div className="embed-controls-section">
            <ButtonFullscreen />
          </div>
        </div>
      </div>
    );
  }
);

LiveStreamControlsMemo.displayName = "LiveStreamControlsMemo";

const LiveStreamControls = () => {
  const { heading } = useGlobalStateContext();
  const { handleClearTimeout, isHoverEnabled, updateHoverState } = useHoverStateContext();
  return (
    <LiveStreamControlsMemo
      heading={heading}
      handleClearTimeout={handleClearTimeout}
      isHoverEnabled={isHoverEnabled}
      updateHoverState={updateHoverState}
    />
  );
};

export default LiveStreamControls;
