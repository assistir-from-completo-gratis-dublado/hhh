import classNames from "../../../utils/classNames";
import { defaultI18n } from "../../constants/i18n";
import { useGlobalStateContext } from "../../contexts/GlobalStateContext";
import { useI18nContext } from "../../contexts/I18nContext";
import { useSubtitleStateContext } from "../../contexts/SubtitleStateContext";
import SettingMenuChecked from "../settings/SettingMenuChecked";
import SettingMenuHeader from "../settings/SettingMenuHeader";
import {
  LiveStreamSettingSections,
  useLiveStreamSettingsContext,
} from "./LiveStreamSettingContext";

const LiveStreamSettingQualities = () => {
  const { sources } = useGlobalStateContext();
  const { i18n } = useI18nContext();
  const { mediaState, setMediaState } = useSubtitleStateContext();
  const { sections, activeSection } = useLiveStreamSettingsContext();
  const activeClass =
    activeSection === LiveStreamSettingSections.qualities
      ? "embed-settings-translate-center"
      : "embed-settings-translate-right";
  return (
    <div
      className={classNames(`embed-settings-section`, activeClass)}
      ref={sections[LiveStreamSettingSections.qualities]}
    >
      <SettingMenuHeader
        title={i18n?.settingsQuality || defaultI18n.settingsQuality}
        backSectionName={LiveStreamSettingSections.main as any}
      />
      <div className="embed-settings-py">
        {sources.map((source, index) => (
          <SettingMenuChecked
            key={`${source.quality} ${index}`}
            handleOnClick={() => {
              setMediaState((prevState) => ({
                ...prevState,
                qualityIndex: index,
              }));
            }}
            settingSection={LiveStreamSettingSections.main as any}
            isActive={mediaState.qualityIndex === index}
            value={source.quality}
          />
        ))}
      </div>
    </div>
  );
};

export default LiveStreamSettingQualities;
