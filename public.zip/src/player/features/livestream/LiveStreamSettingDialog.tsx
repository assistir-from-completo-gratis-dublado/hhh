import classNames from "../../../utils/classNames";
import { memo } from "react";
import ChevronRight from "../../components/Icons/ChevronRight";
import IconQuality from "../../components/Icons/IconQuality";
import { defaultI18n } from "../../constants/i18n";
import { useI18nContext } from "../../contexts/I18nContext";
import {
  LiveStreamSettingSections,
  useLiveStreamSettingsContext,
} from "./LiveStreamSettingContext";
import LiveStreamSettingQualities from "./LiveStreamSettingQualities";

interface LiveStreamSettingDialogProps {
  isShow: boolean;
}

const LiveStreamSettingDialog = ({ isShow }: LiveStreamSettingDialogProps) => {
  const { sections, activeSection, setActiveSection, height } = useLiveStreamSettingsContext();
  console.log("activeSection: ", activeSection);
  const { i18n } = useI18nContext();
  return (
    <div className={classNames("embed-settings-dialog", isShow && "embed-show")}>
      {isShow ? (
        <>
          <div style={{ height }} className="embed-settings-dialog-outer">
            <div
              ref={sections[LiveStreamSettingSections.main]}
              className={`embed-settings-section ${
                activeSection === LiveStreamSettingSections.main
                  ? "embed-settings-translate-center"
                  : "embed-settings-translate-left"
              }`}
            >
              <div className="embed-settings-py">
                <div
                  onClick={() => {
                    setActiveSection(LiveStreamSettingSections.qualities);
                  }}
                  className={classNames("embed-settings-item")}
                >
                  <div className="embed-settings-item-left">
                    <div className="flex-shrink-0">
                      <IconQuality className="embed-icon-md" />
                    </div>
                    <p className="flex-1">{}</p>
                  </div>
                  <div className="embed-settings-item-right">
                    <span>{i18n?.settingsQuality || defaultI18n.settingsQuality}</span>
                    <ChevronRight className="embed-icon-xs" />
                  </div>
                </div>
              </div>
            </div>
            <LiveStreamSettingQualities />
          </div>
          <div className="embed-settings-overlay"></div>
        </>
      ) : null}
    </div>
  );
};

export default memo(LiveStreamSettingDialog);
