import classNames from "../../../utils/classNames";
import { memo } from "react";
import { Link } from "react-router-dom";
import { useHoverStateContext } from "../../contexts/HoverStateContext";
import IconNextEpisode from "../../components/Icons/IconNextEpisode";
import IconGoBack from "../../components/Icons/IconGoBack";
import ButtonScreenshot from "../buttons/ButtonScreenshot";

interface TopHeaderProps {
  onGoBack: () => void;
  urlNextEpisode?: string;
}

interface TopHeaderMemoProps {
  onGoBack: () => void;
  updateHoverState: () => void;
  handleClearTimeout: () => void;
  isHoverEnabled: boolean;
  urlNextEpisode?: string;
}

const TopHeaderMemo = memo((props: TopHeaderMemoProps) => {
  const {
    updateHoverState,
    handleClearTimeout,
    isHoverEnabled,
    onGoBack,
    urlNextEpisode,
    ...others
  } = props;
  return (
    <div
      onTouchEnd={updateHoverState}
      onClick={updateHoverState}
      onMouseEnter={handleClearTimeout}
      className={classNames(!isHoverEnabled && "opacity-0 invisible")}
      {...others}
    >
      <div className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between visible h-24 px-4 md:px-10 gap-x-5 md:gap-x-8">
        {/* <button className="close-player embed-icon-lg"/> */}
        <svg
          onClick={onGoBack}
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="currentColor"
          className="w-6 h-6 embed-icon-lg"
        >
          <path
            fillRule="evenodd"
            d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z"
            clipRule="evenodd"
          />
        </svg>

        {/* <IconGoBack
          className="flex-shrink-0 w-10 h-10 cursor-pointer embed-icon-lg embed-scale"
          onClick={onGoBack}
        /> */}
        <div className="flex items-center gap-10">
		 <div id="logo-player"><img src="https://i.ibb.co/BKVrq5D/logo.gif" alt="DONFLIX" width="134" height="86"/></div>
         {/*  <ButtonScreenshot />*/}
          {urlNextEpisode ? (
            <Link to={urlNextEpisode}>
              <IconNextEpisode className="flex-shrink-0 w-10 h-10 cursor-pointer embed-icon-lg embed-scale" />
            </Link>
          ) : null}
        </div>
      </div>
    </div>
  );
});

TopHeaderMemo.displayName = "TopHeaderMemo";

const TopHeader = (props: TopHeaderProps) => {
  const { updateHoverState, handleClearTimeout, isHoverEnabled } = useHoverStateContext();
  return (
    <TopHeaderMemo
      updateHoverState={updateHoverState}
      handleClearTimeout={handleClearTimeout}
      isHoverEnabled={isHoverEnabled}
      {...props}
    />
  );
};

export default TopHeader;
