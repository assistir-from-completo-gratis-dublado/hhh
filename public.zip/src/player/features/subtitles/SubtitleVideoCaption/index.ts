import SubtitleVideoCaption from "./SubtitleVideoCaption";

export default SubtitleVideoCaption;
