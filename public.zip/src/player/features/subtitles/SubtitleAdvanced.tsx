import IconToggleSubtitle from "../../components/Icons/IconToggleSubtitle";
import { defaultI18n } from "../../constants/i18n";
import { useGlobalStateContext } from "../../contexts/GlobalStateContext";
import { useI18nContext } from "../../contexts/I18nContext";
import { SettingSections, useSettingsContext } from "../../contexts/SettingsContext";
import OpenSubtitlesLangs from "../extra-subtitles/opensubtitles/OpenSubtitlesLangs";
import SettingMenuHeader from "../settings/SettingMenuHeader";
import SettingMenuItem from "../settings/SettingMenuItem";

const SubtitleAdvanced = () => {
  const { meta } = useGlobalStateContext();
  const { i18n } = useI18nContext();
  const { sections, activeSection } = useSettingsContext();
  return (
    <>
      <div
        ref={sections[SettingSections.subtitlesAvanced]}
        className={`embed-settings-section ${
          activeSection === SettingSections.subtitlesAvanced
            ? "embed-settings-translate-center"
            : "embed-settings-translate-left"
        }`}
      >
        <SettingMenuHeader
          title={i18n?.settingsSubtitlesAdvanced || defaultI18n.settingsSubtitlesAdvanced}
          backSectionName={SettingSections.subtitles}
        />
        <div className="embed-settings-py">
          {meta?.imdb_id ? (
            <SettingMenuItem
              settingSection={SettingSections.opensubtitlesLangs}
              icon={<IconToggleSubtitle className="embed-icon-md" />}
              title={i18n?.settingsOpensubtitles || defaultI18n.settingsOpensubtitles}
            />
          ) : null}
        </div>
      </div>
      {meta?.imdb_id &&
      [
        SettingSections.subtitles,
        SettingSections.subtitlesAvanced,
        SettingSections.opensubtitlesLangs,
        SettingSections.opensubtitlesSubs,
      ].includes(activeSection) ? (
        <OpenSubtitlesLangs />
      ) : null}
    </>
  );
};

export default SubtitleAdvanced;
