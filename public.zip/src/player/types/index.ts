export interface i18nType {
  tooltipsServers: string;
  tooltipsEpisodes: string;
  settingsSubtitlesAdvanced: string;
  settingsOpensubtitles: string;
  settingsYifysubtitles: string;
  tooltipsPlay: string;
  tooltipsPause: string;
  tooltipsMute: string;
  tooltipsUnmute: string;
  tooltipsScreenshot: string;
  tooltipsSubtitles: string;
  tooltipsPicInPic: string;
  tooltipsSettings: string;
  tooltipsFullscreen: string;
  tooltipsExitFullscreen: string;
  settingsLanguage: string;
  settingsPlaybackSpeed: string;
  settingsPlaybackSpeedNormal: string;
  settingsSubtitles: string;
  settingsSubtitlesOff: string;
  settingsQuality: string;
  settingsModalOff: string;
  settingsUploadSubtitle: string;
  settingsCustomSubtitles: string;
  settingsFontSize: string;
  settingsBackgroundOpacity: string;
  settingsTextStyle: string;
  settingsFontOpacity: string;
  settingsReset: string;
  settingsSyncSub: string;
  settingsLatency: string;
  settingsColor: string;
  forward: (time: number) => string;
  backward: (time: number) => string;
  tooEarly: string;
  tooLate: string;
  subtitleSyncNoDelay: string;
}

export interface ISource {
  quality: number | string;
  url: string;
  proxy?: string;
}

export interface ISubtitle {
  lang: string;
  language: string;
  url: string;
}

export interface ISubtitleOpensubtitles {
  languageName: string;
  subtitles: ISubtitle[];
}

export interface IKeyBoardShortcut {
  pause?: boolean;
  rewind?: boolean;
  forward?: boolean;
  fullScreen?: boolean;
  mute?: boolean;
  subtitle?: boolean;
}

export interface ISettingsLanguage {
  lang: string;
  language: string;
  image: string;
}
