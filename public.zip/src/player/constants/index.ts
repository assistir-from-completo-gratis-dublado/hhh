export const PLAYER_CONTAINER_CLASS = "embed-container";
export const WRAPPER_PLAYER_ID = "embed-player-wrapper";

export const emptySubtitle = { url: "", lang: "", language: "" };
