import Portal from "../../../components/Portal";
import classNames from "../../../utils/classNames";
import React, { useLayoutEffect, useState } from "react";
import { UsePopoverOptions } from "./usePopover";
import styles from "./Popover.module.css";

export interface PopoverProps extends Partial<UsePopoverOptions>, React.HTMLProps<HTMLDivElement> {
  reference: React.ReactNode;
  referenceProps?: React.HTMLAttributes<HTMLElement>;
  popperProps?: React.HTMLAttributes<HTMLElement>;
  type?: "click" | "hover";
  portalSelector?: string;
}

const noop = () => {};

const Popover: React.FC<PopoverProps> = ({
  reference,
  children,
  popperProps = {},
  referenceProps = {},
  type = "click",
  portalSelector,
}) => {
  const { className: popperClassName = "", ...popperRest } = popperProps!;
  const { className: referenceClassName = "", ...referenceRest } = referenceProps!;
  const [isOpen, setIsOpen] = useState(false);
  const handleOpen: React.MouseEventHandler<HTMLDivElement> = (e) => {
    e.stopPropagation();
    e.preventDefault();
    setIsOpen(true);
  };
  const handleClose: React.MouseEventHandler<HTMLDivElement> = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsOpen(false);
  };
  useLayoutEffect(() => {
    if (!portalSelector) return;
  }, [portalSelector]);
  return (
    <React.Fragment>
      <div
        onClick={type === "click" ? handleOpen : noop}
        onMouseEnter={type === "hover" ? handleOpen : noop}
        onMouseLeave={type === "hover" ? handleClose : noop}
        className={classNames(referenceClassName)}
        {...referenceRest}
      >
        {reference}
      </div>
      {isOpen && (
        <Portal selector={portalSelector}>
          <div
            style={{
              position: "fixed",
              bottom: "110px",
              height: "fit-content",
              width: "fit-content",
              right: "50px",
              zIndex: 100,
            }}
            className={classNames(styles.popperContainer, styles.isOpen, popperClassName)}
            {...popperRest}
          >
            {children}
          </div>
          {isOpen && type === "click" && (
            <div
              style={{
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                zIndex: 40,
              }}
              onClick={handleClose}
            ></div>
          )}
        </Portal>
      )}
    </React.Fragment>
  );
};

export default Popover;
