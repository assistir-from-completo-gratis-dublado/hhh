export enum TMDBMediaType {
  Movie = "movie",
  Person = "person",
  Tv = "tv",
}
export interface TMDBSearchResult {
  adult: boolean;
  backdrop_path?: null | string;
  id: number;
  title?: string;
  original_language?: string;
  original_title?: string;
  description?: string;
  poster_path?: string;
  media_type: TMDBMediaType;
  genre_ids?: number[];
  popularity: number;
  release_date?: Date;
  video?: boolean;
  vote_average?: number;
  vote_count?: number;
  name?: string;
  original_name?: string;
  first_air_date?: Date;
  origin_country?: string[];
  gender?: number;
  known_for_department?: string;
  profile_path?: null;
  known_for?: TMDBSearchResult[];
}
export interface TMDBMovieDetails {
  adult: boolean;
  backdrop_path: string;
  belongs_to_collection: TMDBBelongsToCollection;
  budget: number;
  genres: TMDBGenre[];
  homepage: string;
  id: number;
  imdb_id: string;
  original_language: string;
  original_title: string;
  overview: string;
  popularity: number;
  poster_path: string;
  release_date: Date;
  revenue: number;
  runtime: number;
  spoken_languages: TMDBSpokenLanguage[];
  status: string;
  recommendations: TMDBMovieList;
  tagline: string;
  title: string;
  video: boolean;
  vote_average: number;
  vote_count: number;
  credits: TMDBCredits;
  external_ids: TMDBExternalIDS;
  translations: TMDBDetailsTransition;
}
export interface TMDBDetailsTransition {
  id: number;
  translations: {
    iso_3166_1: string;
    iso_639_1: string;
    name: string;
    english_name: string;
    data: { title: string; name: string; overview: string; homepage: string; tagline: any };
  }[];
}
export interface TMDBSeriesDetails {
  adult: boolean;
  backdrop_path: string;
  created_by: any[];
  episode_run_time: number[];
  first_air_date: Date | string;
  genres: TMDBGenre[];
  homepage: string;
  id: number;
  in_production: boolean;
  languages: string[];
  last_air_date: Date | string;
  name: string;
  next_episode_to_air: null;
  number_of_episodes: number;
  number_of_seasons: number;
  origin_country: string[];
  original_language: string;
  original_name: string;
  overview: string;
  popularity: number;
  poster_path: string;
  seasons: TMDBSeason[];
  spoken_languages: TMDBSpokenLanguage[];
  status: string;
  tagline: string;
  type: string;
  vote_average: number;
  vote_count: number;
  credits: TMDBCredits;
  external_ids: TMDBExternalIDS;
  recommendations: TMDBShowTVLists;
}
export interface TMDBCast {
  adult: boolean;
  gender: number;
  id: number;
  known_for_department: string;
  name: string;
  original_name: string;
  popularity: number;
  profile_path: null | string;
  character?: string;
  credit_id: string;
  order?: number;
  department?: string;
  job?: string;
}
export interface TMDBBelongsToCollection {
  id: number;
  name: string;
  poster_path: string;
  backdrop_path: string;
}
export interface TMDBCredits {
  cast: TMDBCast[];
  crew: TMDBCast[];
}
export interface TMDBCast {
  adult: boolean;
  gender: number;
  id: number;
  known_for_department: string;
  name: string;
  original_name: string;
  popularity: number;
  profile_path: null | string;
  cast_id?: number;
  character?: string;
  credit_id: string;
  order?: number;
  department?: string;
  job?: string;
}
export interface TMDBExternalIDS {
  imdb_id: string;
  wikidata_id: string;
  facebook_id: string;
  instagram_id: string;
  twitter_id: string;
}
export interface TMDBGenre {
  id: number;
  name: string;
}
export interface TMDBSpokenLanguage {
  english_name: string;
  iso_639_1: string;
  name: string;
}
export interface TMDBSeason {
  air_date: string;
  episode_count: number;
  id: number;
  name: string;
  overview: string;
  poster_path: string;
  season_number: number;
}
export interface TMDBEpisode {
  air_date: Date;
  crew: TMDBCast[];
  episode_number: number;
  guest_stars: TMDBCast[];
  name: string;
  overview: string;
  id: number;
  production_code: string;
  runtime: number;
  season_number: number;
  still_path: string;
  vote_average: number;
  vote_count: number;
  external_ids: { imdb_id: string };
}
export interface TMDBMovieResult {
  adult: boolean;
  backdrop_path: null | string;
  genre_ids: number[];
  id: number;
  original_language: string;
  original_title: string;
  overview: string;
  popularity: number;
  poster_path: string;
  release_date: Date;
  title: string;
  video: boolean;
  vote_average: number;
  vote_count: number;
  [key: string]: any;
}
export interface TMDBShowTVCard {
  backdrop_path: string;
  first_air_date: Date;
  genre_ids: number[];
  id: number;
  name: string;
  origin_country: string[];
  original_language: string;
  original_name: string;
  overview: string;
  popularity: number;
  poster_path: string;
  vote_average: number;
  vote_count: number;
}
export interface TMDBPageResult {
  page: number;
  results: any[];
  total_pages: number;
  total_results: number;
}
export interface TMDBMovieList {
  page: number;
  results: TMDBMovieResult[];
  total_pages: number;
  total_results: number;
}
export interface TMDBShowTVResult {
  backdrop_path: string;
  first_air_date: Date;
  genre_ids: number[];
  id: number;
  name: string;
  origin_country: string[];
  original_language: string;
  original_name: string;
  overview: string;
  popularity: number;
  poster_path: string;
  vote_average: number;
  vote_count: number;
  [key: string]: any;
}
export interface TMDBShowTVLists {
  page: number;
  results: TMDBShowTVResult[];
  total_pages: number;
  total_results: number;
}
