export const resizeImageWeserv = (
  url: string,
  width: string | number = "",
  height: string | number = ""
) => `https://images.weserv.nl/?url=${encodeURIComponent(url)}&w=${width}&h=${height}&fit=outside`;
