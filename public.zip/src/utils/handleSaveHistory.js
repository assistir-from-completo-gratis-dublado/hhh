const handleSaveHistory = () => {
  const movieDetails = {
    id: 315162,
    name: "Puss in Boots: The Last Wish",
    episode: 1,
    desc: "Description",
    season: 1,
    poster: "https://image.tmdb.org/t/p/original/kuf6dutpsT0vSVehic3EZIqkOBt.jpg",
    year: 2023,
    score: 7,
    type: "Movie",
    url: "https://imdb-clone-d298iy9cz-vikalp1999.vercel.app/movie/315162", // url detail movie page
  };
  const keyHistoryLS = "movie-history";
  let historyStorage = JSON.parse(localStorage.getItem(keyHistoryLS) || "[]");
  if (!historyStorage) return;
  const foundHistoryIndex = historyStorage.findIndex((history) => {
    return history.id === movieDetails.id && history.url === movieDetails.url;
  });
  if (foundHistoryIndex !== -1) {
    const cloneFoundMovie = historyStorage[foundHistoryIndex];
    historyStorage.splice(foundHistoryIndex, 1);
    historyStorage.unshift(cloneFoundMovie);
    localStorage.setItem(keyHistoryLS, JSON.stringify(historyStorage));
    return;
  }
  localStorage.setItem(keyHistoryLS, JSON.stringify([movieDetails, ...historyStorage]));
};
