import Header from "layouts/Header";
import { isMobile } from "react-device-detect";
import { Helmet } from "react-helmet-async";

const InfoPage = () => {
  return (
    <div className="television-wrapper">
      <Helmet>
        <title>Info - DONFLIX - Assistir Filmes Online Grátis, Assistir Séries Online Grátis, Assistir Animes Online Grátis em Português</title>
        <meta
          name="description"
          content="DONFLIX - Assista filmes online grátis, assista séries online grátis, assista a animes online grátis legendado e dublado em português FULL HD."
        />
      </Helmet>
      <Header />


      <div className="info-page" style={{ marginTop: isMobile ? "90px" : "80px" }}>AJUDA / FAQ<br/><br/><br/>Brevemente..</div>
    </div>
  );
};

export default InfoPage;
