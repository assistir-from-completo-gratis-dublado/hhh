import { allServers, useMediaSources } from "backend/movie-providers/main-providers";
import { IParamsMediaSource } from "backend/movie-providers/types";
import { imageTMDB } from "backend/tmdb/image";
import { TMDBType } from "backend/tmdb/types";
import { useEpisodeDetailsTmdb } from "backend/tmdb/useEpisodeDetailsSeries";
import { useSeriesDetailsTmdb } from "backend/tmdb/useSeriesDetailsTmdb";
import EmbedTmdbPlayer from "components/EmbedTmdbPlayer";
import LoadingMovieScreen from "components/LoadingMovieScreen";
import PopoverServersPicker from "components/PopoverServersPicker";
import SeriesSourcesPicker from "components/SeriesSourcesPicker";
import { PATH_APP } from "constants/path";
import EmbedPlayer from "player";
import IconNextEpisode from "player/components/Icons/IconNextEpisode";
import { WRAPPER_PLAYER_ID } from "player/constants";
import TopHeader from "player/features/others/TopHeader";
import useSaveWatched from "player/hooks/useSavedWatched";
import { sortDefaultLanguage } from "player/utils/helper";
import { useEffect, useMemo } from "react";
import { Helmet } from "react-helmet-async";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import useVideoServersStore from "store";
import { MediaType } from "types";
import { getTitleFromSeriesDetails } from "utils/helper";

const WatchSeriesPage = () => {
  const [searchParams] = useSearchParams();
  const tmdb_id = searchParams.get("tmdb_id");
  const navigate = useNavigate();
  const episodeId = Number(searchParams.get("episode") || 1);
  const seasonId = Number(searchParams.get("season") || 1);
  const { data: details, isLoading: isLoadingTmdb } = useSeriesDetailsTmdb({
    params: {
      tmdb_id: tmdb_id || "",
    },
    config: {
      staleTime: 25 * 60 * 1000,
      cacheTime: 30 * (60 * 1000),
      enabled: Boolean(tmdb_id),
    },
  });
  const { data: episodeDetailsTmdb } = useEpisodeDetailsTmdb({
    params: {
      tmdb_id: details?.id as number,
      episodeId,
      seasonId,
    },
    config: {
      staleTime: 5 * 60 * 1000,
      cacheTime: 6 * (60 * 1000),
      enabled: Boolean(details?.id),
    },
  });
  const paramsMediaSources: IParamsMediaSource = {
    title: getTitleFromSeriesDetails(details as TMDBType.ISeriesDetails),
    extraData: {
      tmdb_id: details?.id,
      imdb_id: episodeDetailsTmdb?.external_ids.imdb_id,
      mediaType: MediaType.TV,
      titlePortuguese: details?.title_portuguese,
      year: new Date(details?.first_air_date as any).getFullYear(),
      episodeId,
      seasonId,
    },
  };
  const nextEpisodeUrl = useMemo(() => {
    if (!details) return "";
    const currentSeason = details.seasons.find((s) => s.season_number === Number(seasonId));
    if (!currentSeason) return "";
    const nextEpisode =
      currentSeason.episode_count > Number(episodeId + 1)
        ? `${PATH_APP.watchTV}?tmdb_id=${tmdb_id}&season=${currentSeason.season_number}&episode=${
            episodeId + 1
          }`
        : "";
    return nextEpisode;
  }, [details, episodeId, seasonId, tmdb_id]);
  const { startTime, handleSaveProgressWatched } = useSaveWatched({
    details: details as TMDBType.ISeriesDetails,
    title: getTitleFromSeriesDetails(details as TMDBType.ISeriesDetails),
    mediaType: MediaType.TV,
  });
  const { activeServer, setActiveServer, setServers } = useVideoServersStore((state) => state);
  const { isLoading: isLoadingSources, data: dataMediaSources } = useMediaSources({
    params: paramsMediaSources,
    config: {
      enabled: Boolean(details?.id),
      onSuccess(data) {
        setServers(data.servers);
        setActiveServer(data.activeServer);
      },
    },
  });
  useEffect(() => {
    setServers(allServers.map((x) => Object.assign({}, { ...x, isSuccess: true })));
    setActiveServer(allServers[0].name);
  }, [tmdb_id, setActiveServer, setServers]);
  if (isLoadingTmdb) return <LoadingMovieScreen />;
  if (activeServer === "Embed") {
    return (
      <EmbedTmdbPlayer
        urlEmbed={`https://vidsrc.to/embed/tv/${details?.id}/${seasonId}/${episodeId}`}
        handleGoBack={() => {
          setServers(allServers.map((x) => Object.assign({}, { ...x, isSuccess: true })));
          setActiveServer(allServers[0].name);
        }}
      />
    );
  }
  return (
    <div className="fixed w-full h-full" id={WRAPPER_PLAYER_ID}>
      <Helmet>
        <title>Assistir Série {details?.name || details?.original_name} Completa Grátis Legendado e Dublado Online HD</title>
        <meta property="og:description" content={details?.overview} />
        <meta
          property="og:image"
          content={`https://image.tmdb.org/t/p/w780${details?.backdrop_path}`}
        />
      </Helmet>
      <EmbedPlayer
        poster={imageTMDB.imageOriginal(details?.backdrop_path as string)}
        sources={dataMediaSources?.mediaSources.sources || []}
        subtitles={sortDefaultLanguage(dataMediaSources?.mediaSources.subtitles || [])}
        meta={{
          imdb_id: paramsMediaSources.extraData.imdb_id,
          title: paramsMediaSources.title,
          year: paramsMediaSources.extraData.year,
        }}
        topHeaderComponent={
          <TopHeader onGoBack={() => navigate(`${PATH_APP.detailsTv}?tmdb_id=${tmdb_id}`)} />
        }
        startTime={startTime}
        onTimeUpdate={handleSaveProgressWatched}
        heading={`S${seasonId} E${episodeId}: ${getTitleFromSeriesDetails(
          details as TMDBType.ISeriesDetails
        )}`}
        rightControlsComponent={
          <>
            {nextEpisodeUrl ? (
              <Link to={nextEpisodeUrl}>
                <IconNextEpisode className="flex-shrink-0 w-10 h-10 cursor-pointer embed-icon-lg embed-scale" />
              </Link>
            ) : null}
            <SeriesSourcesPicker details={details as TMDBType.ISeriesDetails} />
            <PopoverServersPicker
              isLoading={isLoadingSources}
              paramsMediaSources={paramsMediaSources}
            />
          </>
        }
      />
    </div>
  );
};

export default WatchSeriesPage;
