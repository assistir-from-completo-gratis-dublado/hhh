import SeriesDetailsDesktop from "features/details/SeriesDetails/SeriesDetailsDesktop";
import SeriesDetailsMobile from "features/details/SeriesDetails/SeriesDetailsMobile";
import { isMobile } from "react-device-detect";

const SeriesDetailsPage = () => {
  return (
    <div className="television-wrapper" style={{ position: "relative" }}>
      <div id="slider_tvshow" className="slider fadein" style={{ top: 0, opacity: 1 }}>
        {isMobile ? <SeriesDetailsMobile /> : <SeriesDetailsDesktop />}
      </div>
    </div>
  );
};

export default SeriesDetailsPage;
