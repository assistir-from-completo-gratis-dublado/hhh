import { LocalStorage } from "constants/localStorage";
import HistoryItem from "features/history/components/HistoryItem";
import Header from "layouts/Header";
import { IHistoryItem } from "player/hooks/useSavedWatched";
import { useState } from "react";
import { isMobile } from "react-device-detect";
import { Helmet } from "react-helmet-async";

const HistoryPage = () => {
  const [history, setHistory] = useState<IHistoryItem[]>(
    JSON.parse(localStorage.getItem(LocalStorage.history) || "[]")
  );
  const handleClearHistory = () => {
    // eslint-disable-next-line no-restricted-globals
    const isConfirmed = confirm("Tens a certeza que queres remover tudo?");
    if (isConfirmed) {
      localStorage.removeItem(LocalStorage.history);
      setHistory([]);
    }
  };
  const handleRemoveHistory = (movie: IHistoryItem) => {
    const removedHistory = history.filter((item) => item.key !== movie.key);
    setHistory(removedHistory);
    localStorage.setItem(LocalStorage.history, JSON.stringify(removedHistory));
  };
  return (
    <div className="television-wrapper">
      <Helmet>
        <title>Histórico - DONFLIX - Assistir Filmes Online Grátis, Assistir Séries Online Grátis, Assistir Animes Online Grátis em Português</title>
        <meta
          name="description"
          content="DONFLIX - Assista filmes online grátis, assista séries online grátis, assista a animes online grátis legendado e dublado em português FULL HD."
        />
      </Helmet>
      <Header />
      <div className="px-4 lg:px-10">
        <div
          className="flex flex-wrap gap-4 mb-6 md:items-center md:justify-between"
          style={{ marginTop: isMobile ? "90px" : "85px" }}
        >
          <h1 className="text-2xl font-semibold">Continuar assistir:</h1>
          <button onClick={handleClearHistory}>Remover tudo</button>
        </div>
        {history.length > 0 && (
          <div className="space-y-4">
            {history.map((movie) => (
              <HistoryItem
                key={movie.key}
                movie={movie}
                handleRemoveHistory={handleRemoveHistory}
              />
            ))}
          </div>
        )}
        {history.length === 0 && <div className="mt-10 text-center">Ainda não assististe nada.</div>}
      </div>
    </div>
  );
};

export default HistoryPage;
