import { useInfiniteQuery } from "@tanstack/react-query";
import { imageTMDB } from "backend/tmdb/image";
import tmdbFetch from "backend/tmdb/tmdbFetch";
import CheckInView from "components/CheckInView";
import LazyImage from "components/LazyImage";
import MovieGrid from "features/core/MovieGrid";
import ButtonAddFavorite from "features/details/ButtonAddFavorite";
import DetailsRating from "features/details/DetailsRating";
import ChangeMovieCardSize from "features/home/components/ChangeMovieCardSize";
import ModalSeriesDetails from "features/home/components/ModalSeriesDetails";
import SidebarSeries from "features/home/components/SidebarSeries";
import { useDebounce } from "hooks/useDebounce";
import Header from "layouts/Header";
import { useMemo, useState } from "react";
import { isMobile } from "react-device-detect";
import { Helmet } from "react-helmet-async";
import { MediaType } from "types";
import { TMDBShowTVLists, TMDBShowTVResult } from "types/tmdb";
import { getUniqueListBy } from "utils/helper";

const SeriesPage = () => {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState("popular");
  const [keyword, setKeyword] = useState("");
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const debouncedKeyword = useDebounce(keyword, 500);
  const [modalInfo, setModalInfo] = useState<TMDBShowTVResult | null>(null);
  const {
    isLoading,
    fetchNextPage,
    hasNextPage,
    data: dataMovies = null,
  } = useInfiniteQuery({
    queryKey: ["Series", sortBy, selectedCategory, selectedYear, debouncedKeyword],
    queryFn: async ({ pageParam = 1 }) => {
      try {
        const data: TMDBShowTVLists = await tmdbFetch(
          debouncedKeyword
            ? `/search/tv?language=pt-BR&with_original_language=en`
            : `/${selectedCategory || selectedYear ? "discover/tv" : `tv/${sortBy}`}?region=US`,
          {
            parseResponse: JSON.parse,
            params: {
              page: pageParam,
              query: debouncedKeyword,
              with_genres: selectedCategory,
              first_air_date_year: selectedYear,
            },
          }
        );
        if (debouncedKeyword) {
          data.results = data.results.sort((a, b) => b.popularity - a.popularity);
        }
        return data;
      } catch (error) {
        return null;
      }
    },
    keepPreviousData: true,
    getPreviousPageParam: (firstPage) => (firstPage ? firstPage.page + 1 : undefined),
    getNextPageParam: (lastPage) => (lastPage ? lastPage.page + 1 : undefined),
    staleTime: 10 * 60 * 1000,
    cacheTime: 15 * (60 * 1000),
  });
  const moviesList: TMDBShowTVResult[] = useMemo(() => {
    return getUniqueListBy(
      (dataMovies?.pages?.flatMap((page) => page?.results) as TMDBShowTVResult[]) || [],
      "id"
    );
  }, [dataMovies?.pages]);
  const handleChangeKeyword = (value: string) => {
    setKeyword(value);
    setSelectedCategory(null);
    setSortBy("popular");
    setSelectedYear(null);
  };
  if (isLoading) return null;
  return (
    <div className="television-wrapper">
      <Helmet>
        <title>DONFLIX - Assistir Filmes Online Grátis, Assistir Séries Online Grátis, Assistir Animes Online Grátis em Português</title>
        <meta
          name="description"
          content="DONFLIX - Assista filmes online grátis, assista séries online grátis, assista a animes online grátis legendado e dublado em português FULL HD."
        />
      </Helmet>
      <Header keyword={keyword} handleChangeKeyword={handleChangeKeyword} />
      <MovieGrid style={{ marginTop: isMobile ? "90px" : "70px" }}>
        {moviesList.map((movie) => (
          <div
            key={movie.id}
            onClick={() => setModalInfo(movie)}
            style={{
              transitionDelay: "0s, 0.0434783s",
              opacity: 1,
              transform: "scale(1, 1)",
            }}
            className="movie p1"
          >
            <LazyImage
              src={`https://image.tmdb.org/t/p/w300${movie.poster_path}`}
              alt={movie.name}
            />
            <div className="poster_slide">
              <div className="poster_slide_cont">
                <div className="poster_slide_bg" />
                <div className="poster_slide_details">
                  <div className="title">
                    {movie.name || movie.original_name}
                    <div className="year">
                      <ButtonAddFavorite
                        mediaType={MediaType.TV}
                        tmdbId={movie.id.toString()}
                        poster={imageTMDB.image300(movie.poster_path)}
                        title={movie.name || movie.original_name}
                        year={new Date(movie.first_air_date).getFullYear()}
                        score={movie.vote_average}
                      />{" "}
                      &nbsp; {new Date(movie.first_air_date).getFullYear()}
                    </div>
                  </div>
                  <div className="details">
                    <div className="tools" style={{ display: "none", fontSize: "24.48px" }}>
                      <ButtonAddFavorite
                        mediaType={MediaType.TV}
                        tmdbId={movie.id.toString()}
                        poster={imageTMDB.image300(movie.poster_path)}
                        title={movie.name || movie.original_name}
                        year={new Date(movie.first_air_date).getFullYear()}
                        score={movie.vote_average}
                      />{" "}
                      &nbsp;
                      <span className="icon2 download" />
                    </div>
                    <DetailsRating score={movie.vote_average / 2} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </MovieGrid>
      {modalInfo ? <ModalSeriesDetails movie={modalInfo} setModalInfo={setModalInfo} /> : null}
      {hasNextPage && Boolean(dataMovies?.pages.slice(-1)?.[0]?.results.length) && (
        <CheckInView onInView={fetchNextPage} className="flex justify-center pt-2 mt-5" />
      )}
      <ChangeMovieCardSize />
      <SidebarSeries
        setKeyword={setKeyword}
        setSelectedYear={setSelectedYear}
        setSelectedCategory={setSelectedCategory}
        setSortBy={setSortBy}
        selectedCategory={selectedCategory}
      />
    </div>
  );
};

export default SeriesPage;
