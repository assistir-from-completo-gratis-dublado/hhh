import LazyImage from "components/LazyImage";
import { LocalStorage } from "constants/localStorage";
import MovieGrid from "features/core/MovieGrid";
import ButtonAddFavorite from "features/details/ButtonAddFavorite";
import Header from "layouts/Header";
import { isMobile } from "react-device-detect";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { FavoriteCardType } from "types";

const FavoritePage = () => {
  const followLocalStorage: FavoriteCardType[] = JSON.parse(
    localStorage.getItem(LocalStorage.favoriteList) || "[]"
  );
  return (
    <div className="television-wrapper">
      <Helmet>
        <title>Favoritos - DONFLIX - Assistir Filmes Online Grátis, Assistir Séries Online Grátis, Assistir Animes Online Grátis em Português</title>
        <meta
          name="description"
          content="DONFLIX - Assista filmes online grátis, assista séries online grátis, assista a animes online grátis legendado e dublado em português FULL HD."
        />
      </Helmet>
      <Header />
      <MovieGrid style={{ marginTop: isMobile ? "90px" : "70px" }}>
        {followLocalStorage.map((movie) => (
          <Link
            to={`/details/${movie.mediaType}?tmdb_id=${movie.tmdbId}`}
            style={{
              transitionDelay: "0s, 0.0434783s",
              opacity: 1,
              transform: "scale(1, 1)",
            }}
            className="movie p1"
          >
            <LazyImage src={movie.poster} alt={movie.title} />
            <div className="poster_slide">
              <div className="poster_slide_cont">
                <div className="poster_slide_bg" />
                <div className="poster_slide_details">
                  <div className="title">
                    {movie.title}
                    <div className="year">
                      <ButtonAddFavorite
                        mediaType={movie.mediaType}
                        tmdbId={movie.tmdbId}
                        poster={movie.poster}
                        title={movie.title}
                        score={movie.score}
                        year={movie.year}
                      />
                      &nbsp; {movie.year}
                    </div>
                  </div>
                  <div className="details">
                    <div className="tools" style={{ display: "none", fontSize: "24.48px" }}>
                      <ButtonAddFavorite
                        mediaType={movie.mediaType}
                        tmdbId={movie.tmdbId}
                        poster={movie.poster}
                        title={movie.title}
                        score={movie.score}
                        year={movie.year}
                      />
                    </div>
                    <div className="stars" style={{ fontSize: "34.68px" }}>
                      <span className="icon star" />
                      <span className="icon star" />
                      <span className="icon star" />
                      <span className="icon star_half" />
                      <span className="icon star_empty" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </MovieGrid>
      {followLocalStorage.length === 0 && <div className="mt-10 text-center">Nenhum conteúdo adicionado aos favoritos.</div>}
    </div>
  );
};

export default FavoritePage;
