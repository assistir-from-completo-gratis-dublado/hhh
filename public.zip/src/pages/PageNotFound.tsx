const PageNotFound = () => {
  return (
    <div className="television-wrapper">
      <h2>404: Page Not Found</h2>
      <p>ERRO!</p>
    </div>
  );
};

export default PageNotFound;
