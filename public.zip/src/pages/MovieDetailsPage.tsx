import MovieDetailsDesktop from "features/details/MovieDetails/MovieDetailsDesktop";
import MovieDetailsMobile from "features/details/MovieDetails/MovieDetailsMobile";
import { isMobile } from "react-device-detect";

const DetailsPage = () => {
  return (
    <div className="television-wrapper" style={{ position: "relative" }}>
      <div id="slider_movie" className="slider fadein" style={{ top: 0, opacity: 1 }}>
        {isMobile ? <MovieDetailsMobile /> : <MovieDetailsDesktop />}
      </div>
    </div>
  );
};

export default DetailsPage;
