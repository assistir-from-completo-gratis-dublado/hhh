import React from "react";

const IconStar = () => {
  return <span className="icon star" />;
};

export default IconStar;
