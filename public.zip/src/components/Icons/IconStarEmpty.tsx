import React from "react";

const IconStarEmpty = () => {
  return <span className="icon star_empty" />;
};

export default IconStarEmpty;
