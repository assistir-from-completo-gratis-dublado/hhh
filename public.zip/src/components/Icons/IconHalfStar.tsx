import React from "react";

const IconHalfStar = () => {
  return <span className="icon star_half" />;
};

export default IconHalfStar;
