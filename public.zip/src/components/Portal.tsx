import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";

interface PortalProps {
  children: React.ReactNode;
  selector?: string;
}

const Portal: React.FC<PortalProps> = ({ children, selector = "#__next" }) => {
  const [element, setElement] = useState<Element | null>(null);
  useEffect(() => {
    const portalElement = document.querySelector(selector);
    setElement(portalElement);
  }, [selector]);
  return element ? ReactDOM.createPortal(children, element) : null;
};

export default React.memo(Portal);
