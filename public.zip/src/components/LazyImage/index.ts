import LazyImage from "./LazyImage";

export default LazyImage;
