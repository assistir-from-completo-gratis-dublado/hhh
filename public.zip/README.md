## Run project

cd to root project folder
npm install to install all package
npm run start -> localhost:3000

## Deloy project to Vercel,Cloudflare, Netlify, ...

Cloudflare: https://developers.cloudflare.com/pages/framework-guides/deploy-a-react-site/

## Project embed player

Go to src/configs/index.ts to config settings app

## Setup Free Proxy to bypass Cors and Opensubtitles

1. Create a Cloudflare account at [https://dash.cloudflare.com](https://dash.cloudflare.com).
2. Navigate to `Workers`.
3. If it asks you, choose a subdomain.
4. If it asks for a workers plan, press "Continue with free".
5. Create a new service with a name of your choice. Must be type `HTTP handler`.
6. On the service page, Click `Quick edit`.
7. Remove the template code in the quick edit window.
8. Open `api-bypass-cors.js` at `src/backend/proxy/api-bypass-cors.js` in Notepad, Visual Studio Code or similar.
9. Copy the text contents of the `api-bypass-cors.js` file.
10. Paste the text contents into the edit screen of the Cloudflare service worker.
11. Click `Save and deploy` and confirm.
12. Get link deloyed proxy and update url `BYPASS_CORS_WORKERS` https://proxy-for-movie-app.yashgajbhiye10.workers.dev to new deloy proxy at `src/constants/path.ts`
13. Deploy similar `api-opensubtitles.js` open at `src/backend/proxy/api-opensubtitles.js` to Cloudflare and update url `API_OPENSUBTITLES` https://opensubtitles-api.thanhduy1309a.workers.dev to new deloy proxy at `src/constants/path.ts`

```
src/constants/path.ts

export const PATH_API = {
  BYPASS_CORS_WORKERS: (url: string) => {
    return `https://proxy-for-movie-app.yashgajbhiye10.workers.dev/?destination=${encodeURIComponent(
      url
    )}`;
  },
  API_OPENSUBTITLES: "https://opensubtitles-api.thanhduy1309a.workers.dev/?destination=",
  BYPASS_CORS_CORIO: (url: string) => {
    return `https://corsproxy.io/?${encodeURIComponent(url)}`;
  },
};
```

All servers using for player at : `src/backend/movie-providers/main-providers.ts`

```
export const allServers: IServer[] = [
  { name: "Server 1", note: "Fast", get: getMediaSourcesFlixhq, isSuccess: true },
  // { name: "Remotestream", note: "Fast", get: getMediaSourcesRemotestream, isSuccess: true }, disabled because cors https://fsa.remotestre.am/Movies/315162/315162.m3u8
  { name: "Server 2", note: "Fast", get: getMediaSourcesSuperstream, isSuccess: true },
  { name: "Server 3", note: "Medium", get: getMediaSourcesLoveflix, isSuccess: true },
  { name: "Server 4", note: "Audio", get: getMediaSourcesVisioncine, isSuccess: true },
  // { name: "Embed", note: "Player contain ads", get: () => emptyMediaSources, isSuccess: true }, temp disabled because player contain ads
];
```
